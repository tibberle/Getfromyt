export class TimerUtils {
  public static sleepXSeconds(numberOfSeconds: number) {
    return new Promise((res) => setTimeout(res, numberOfSeconds * 1000));
  }
}
