const supportedLocale = ["en", "vi"];
const defaultLocale = "vi";

export const getInitialLocale = () => {
  const [browserSetting] = navigator.language.split("-");
  if (supportedLocale.includes(browserSetting)) {
    return browserSetting;
  }

  return defaultLocale;
};
