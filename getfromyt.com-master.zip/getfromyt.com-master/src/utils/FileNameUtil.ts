import { YoutubeType } from "../Models/Youtube";

export class FileNameUtil {
  public static getFileNameWithBranding(fileName: string) {
    return `[ Getfromyt.com ] ${fileName}`;
  }
  public static getFileNameWithExtension(params: {
    fileName: string;
    youtubeType: YoutubeType;
    custom?: string;
  }) {
    const { fileName, youtubeType, custom } = params;
    const cleanedFileName = this.cleanFileNameForFFmpegIO(fileName);
    const extension = custom
      ? custom
      : youtubeType === YoutubeType.Audio
      ? "mp3"
      : "mp4";

    return `${cleanedFileName}.${extension}`;
  }

  public static combineFileNameWithTime(params: {
    fileName: string;
    start: string;
    end: string;
  }) {
    const { fileName, start, end } = params;
    return this.cleanFileNameForFFmpegIO(`${fileName}-${start}-${end}`);
  }

  public static getAudioOnlyFileName(
    fileName: string,
    extension: "aac" | "mp3" | "m4a" = "mp3"
  ) {
    return `${fileName}-audio-only.${extension}`;
  }

  public static getVideoOnlyFileName(fileName: string) {
    return `${fileName}-video-only.mp4`;
  }

  public static cleanFileNameForFFmpegIO(fileName: string) {
    return fileName.replaceAll(".", "").replaceAll(":", "");
  }
}
