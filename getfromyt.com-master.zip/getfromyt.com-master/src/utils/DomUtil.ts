export class DomUtil {
  public static downloadBlob(params: { blob: Blob; fileName: string }) {
    const { blob, fileName } = params;

    const downlaodUrl = window.URL.createObjectURL(blob);
    const aElement = document.createElement("a");
    aElement.href = downlaodUrl;
    aElement.download = fileName;
    aElement.click();
    aElement.remove();
  }

  public static downloadFIle(file: File) {
    const downlaodUrl = window.URL.createObjectURL(file);
    const aElement = document.createElement("a");
    aElement.href = downlaodUrl;
    aElement.download = file.name;
    aElement.click();
    aElement.remove();
  }

  public static getBlobDuration(blob: Blob): Promise<number> {
    const tempVideoEl = document.createElement("video");

    const durationP = new Promise((resolve, reject) => {
      tempVideoEl.addEventListener("loadedmetadata", () => {
        // Chrome bug: https://bugs.chromium.org/p/chromium/issues/detail?id=642012
        if (tempVideoEl.duration === Infinity) {
          tempVideoEl.currentTime = Number.MAX_SAFE_INTEGER;
          tempVideoEl.ontimeupdate = () => {
            tempVideoEl.ontimeupdate = null;
            resolve(tempVideoEl.duration);
            tempVideoEl.currentTime = 0;
          };
        }
        // Normal behavior
        else resolve(tempVideoEl.duration);
      });
      tempVideoEl.onerror = (event: any) => reject(event.target.error);
    });

    tempVideoEl.src = window.URL.createObjectURL(blob);

    return durationP as Promise<number>;
  }
}
