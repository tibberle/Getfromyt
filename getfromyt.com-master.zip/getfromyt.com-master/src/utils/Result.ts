export class Result<T> {
    // private 
}