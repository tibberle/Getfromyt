import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import {
  getNumberOfUsageForToday,
  setNumberOfUsageForToday,
} from "../services/usageService";
import { useAnDoML } from "./useAnDoML";
import { useDetectAdBlock } from "./useDetectAdBlock";

export const useUsage = () => {
  const [counter, setCounter] = useState(getNumberOfUsageForToday());
  const { adBlockDetected } = useDetectAdBlock();
  const { andoML } = useAnDoML();

  const increaseCounter = () =>
    setCounter((counter) => {
      const updatedCounter = counter + 1;
      setNumberOfUsageForToday(updatedCounter);
      return updatedCounter;
    });

  useEffect(() => {
    getNumberOfUsageForToday();
  }, []);

  const numberOfFreeUsage = andoML ? 1 : 2;
  const numberOfDownloadBeforeBlock = andoML ? 2 : 3;

  const blocked = counter >= numberOfDownloadBeforeBlock && adBlockDetected;

  if (blocked) {
    toast.error(
      `You have used up all ${numberOfDownloadBeforeBlock} free download times today, please disable adblock continue`
    );
  } else if (
    counter > 0 &&
    counter < numberOfDownloadBeforeBlock &&
    adBlockDetected
  ) {
    toast.info(
      `You have used ${counter} out of ${numberOfDownloadBeforeBlock} free download time today, please disable adblock continue`
    );
  }

  return {
    increaseCounter,
    blocked,
    freeUsage: counter <= numberOfFreeUsage,
  };
};
