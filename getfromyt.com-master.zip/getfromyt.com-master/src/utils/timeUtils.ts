export const millisecondToHHMMSSXX = (millisecond: number) => {
  const milliseconds = ("0" + (Math.floor(millisecond / 10) % 100)).slice(-2);
  const seconds = ("0" + (Math.floor(millisecond / 1000) % 60)).slice(-2);
  const minutes = ("0" + (Math.floor(millisecond / 60000) % 60)).slice(-2);
  const hours = ("0" + Math.floor(millisecond / 3600000)).slice(-2);

  return { milliseconds, seconds, minutes, hours };
};

export const formatMillisecondToHHMMSSXX = (params: {
  milliseconds: string;
  seconds: string;
  minutes: string;
  hours: string;
}) => {
  const { hours, milliseconds, minutes, seconds } = params;
  return `${hours}:${minutes}:${seconds}.${milliseconds}`;
};

export const convertSecondsToHHMMSSXX = (numberOfSeconds: number) =>
  formatMillisecondToHHMMSSXX(millisecondToHHMMSSXX(numberOfSeconds * 1000));
