import React from "react";

export interface StartTakingActionInput {
  action: () => Promise<void>;
  onSuccess: () => void;
  onError: (error: any) => void;
}

export const useAsyncAction = () => {
  const [takingAction, setTakingAction] = React.useState<boolean>(false);
  const [error, setError] = React.useState<any>(null);

  const startTakingAction = async (params: StartTakingActionInput) => {
    const { action, onSuccess, onError } = params;

    setTakingAction(true);
    try {
      await action();
      onSuccess();
      setTakingAction(false);
    } catch (error) {
      onError(error);
      setTakingAction(false);
    }
  };

  return { error, takingAction, setError, startTakingAction };
};
