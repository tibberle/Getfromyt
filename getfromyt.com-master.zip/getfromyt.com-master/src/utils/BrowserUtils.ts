export class BrowserUtils {
  public static isMobile() {
    return matchMedia("(pointer:coarse)").matches;
  }
}
