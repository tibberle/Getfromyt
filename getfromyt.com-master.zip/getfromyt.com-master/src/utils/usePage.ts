import { useRouter } from "next/router";

export const usePage = () => {
  const { pathname } = useRouter();

  const getPageName = (): "HomePage" | "CutterPage" => {
    switch (pathname) {
      case "/":
        return "HomePage";
      case "/youtube-cutter":
        return "CutterPage";
      default:
        return "HomePage";
    }
  };
  return {
    pageName: getPageName(),
  };
};
