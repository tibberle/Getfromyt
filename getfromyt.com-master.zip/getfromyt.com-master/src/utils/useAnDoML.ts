import React from "react";
import { tz } from "moment-timezone";

const indianTimeZones = tz
  .names()
  .filter(
    (timeZone) =>
      timeZone.toLowerCase().includes("indian/") ||
      timeZone.toLowerCase().includes("calcutta")
  );

export const useAnDoML = () => {
  const [andoML, setAnDoML] = React.useState<boolean | null>(null);

  React.useEffect(() => {
    const currentTimezone = tz.guess(true);

    setAnDoML(indianTimeZones.includes(currentTimezone));
  }, []);

  return { andoML };
};
