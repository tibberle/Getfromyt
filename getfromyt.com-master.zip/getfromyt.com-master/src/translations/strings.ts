import { Strings } from "./types";
const strings: Strings = {
  en: {
    "/": {},
    bestYoutubeToMp3: "Best YouTube To Mp3 Converter Online For Free",
    mergeAndDownloadOnline: "Merge and download videos & audios online",
  },
  vi: {
    "/": {},
    bestYoutubeToMp3: "Vietnam 1",
    mergeAndDownloadOnline: "Vietnam 2",
  },
};

export default strings;
