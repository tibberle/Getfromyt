import "@emotion/react";
import "react";
import { Interpolation, Theme } from "@emotion/react";
import { Theme as CustomTheme } from "./interfaces/interfaces";

declare module "@emotion/react" {
  export interface Theme extends CustomTheme {}
}

declare module "react" {
  interface Attributes {
    css?: Interpolation<Theme>;
  }
}
