import { darken } from "polished";
import { ThemeColor } from "../interfaces/interfaces";

const secondaryContrast = 0.05;
const tertiaryContrast = 0.15;

const primaryColor = "#33b1ff";
const secondaryColor = "#00e6cb";
const backgroundColor = "#ffffff";
const textColor = "#000000";
const errorColor = "#ff6666";
const disabledColor = "#e0e0e0";
const warningColor = "#E6CB00";

export const colors: ThemeColor = {
  primaryColor: {
    primary: primaryColor,
    secondary: darken(secondaryContrast, primaryColor),
    tertiary: darken(tertiaryContrast, primaryColor),
  },
  successColor: {
    primary: secondaryColor,
    secondary: darken(secondaryContrast, secondaryColor),
    tertiary: darken(tertiaryContrast, secondaryColor),
  },
  backgroundColor: {
    primary: backgroundColor,
    secondary: darken(secondaryContrast, backgroundColor),
    tertiary: darken(tertiaryContrast, backgroundColor),
  },
  textColor: {
    primary: textColor,
    secondary: "#7f7f7f",
    tertiary: "#999999",
  },
  errorColor: {
    primary: errorColor,
    secondary: darken(secondaryContrast, errorColor),
    tertiary: darken(tertiaryContrast, errorColor),
  },
  disabledColor: {
    primary: disabledColor,
    secondary: darken(secondaryContrast, disabledColor),
    tertiary: darken(tertiaryContrast, disabledColor),
  },
  warningColor: {
    primary: warningColor,
    secondary: darken(secondaryContrast, warningColor),
    tertiary: darken(tertiaryContrast, warningColor),
  },
  white: "#ffffff",
};
