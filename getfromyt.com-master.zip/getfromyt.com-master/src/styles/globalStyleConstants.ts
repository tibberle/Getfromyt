export const getPixelToRem = (pixel: number) => pixel / DEFAULT_FONT_SIZE;

export const DEFAULT_FONT_SIZE = 16;
export const DEFAULT_BORDER_RADIUS = 5;
export const DEFAULT_TRANSITION_TIME = 0.3;

export const EXTRA_SMALL_SPACING_REM = getPixelToRem(4);
export const SMALL_SPACING_REM = getPixelToRem(10);
export const DEFAULT_SPACING_REM = getPixelToRem(16);
export const LARGE_SPACING_REM = getPixelToRem(22);
export const EXTRA_LARGE_SPACING_REM = getPixelToRem(28);
