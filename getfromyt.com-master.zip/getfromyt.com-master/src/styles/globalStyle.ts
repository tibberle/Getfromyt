import { css } from "@emotion/react";
import { DEFAULT_FONT_SIZE } from "./globalStyleConstants";
import { theme } from "./theme";

export const globalStyle = css`
  html {
    box-sizing: border-box;
    font-size: ${DEFAULT_FONT_SIZE}px;
    font-family: ${theme.typography.primary};
    @media (max-width: 570px) {
      font-size: 14px;
    }
    @media (max-width: 500px) {
      font-size: 12px;
    }
    @media (max-width: 430px) {
      font-size: 10px;
    }
  }
  *,
  *:before,
  *:after {
    box-sizing: inherit;
  }

  body {
    margin: 0;
    padding: 0;
    background-color: ${theme.backgroundColor.secondary};
    @media (max-width: 430px) {
      height: 100%;
    }
  }

  strong,
  b {
    font-weight: bolder;
  }

  a {
    text-decoration: none;
    font-size: inherit;
    cursor: pointer;
    color: #ff6666;
  }

  .rc-slider-handle-dragging.rc-slider-handle-dragging.rc-slider-handle-dragging {
    box-shadow: none;
  }

  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    margin: 0.67rem 0;
  }

  p {
    margin: 0.4rem 0;
  }
`;
