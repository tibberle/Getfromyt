export interface Typography {
  primary: string;
  secondary: string;
  tertiary: string;
}

export interface TypeScale {
  header1: string;
  header2: string;
  header3: string;
  header4: string;
  header5: string;
  paragraph: string;
  helperText: string;
  copyrightText: string;
}

export interface Fonts {
  typography: Typography;
  typeScale: TypeScale;
}

export interface Color {
  primary: string;
  secondary: string;
  tertiary: string;
}

export interface Status {
  error: Color;
  warning: Color;
  success: Color;
}

export interface ThemeColor {
  primaryColor: Color;
  successColor: Color;
  backgroundColor: Color;
  textColor: Color;
  warningColor: Color;
  errorColor: Color;
  disabledColor: Color;
  white: string;
}

export interface Theme extends ThemeColor {
  typography: Typography;
  typeScale: TypeScale;
}
