import { colors } from "./colors/colors";
import { typeScale } from "./fonts/typeScale";
import { typography } from "./fonts/typography";
import { Theme as CustomTheme } from "./interfaces/interfaces";

export const theme: CustomTheme = {
  primaryColor: colors.primaryColor,
  successColor: colors.successColor,
  backgroundColor: colors.backgroundColor,
  textColor: colors.textColor,
  errorColor: colors.errorColor,
  disabledColor: colors.disabledColor,
  warningColor: colors.warningColor,
  white: colors.white,
  typeScale,
  typography,
};
