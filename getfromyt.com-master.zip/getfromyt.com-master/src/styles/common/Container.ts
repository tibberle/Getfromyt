/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import { EXTRA_LARGE_SPACING_REM } from "../globalStyleConstants";

export const ContainerMaxWidth = css`
  /* padding: 0 ${EXTRA_LARGE_SPACING_REM}rem; */
  @media (min-width: 1024px) {
    max-width: 1024px;
  }
`;

export const Container = styled.article`
  width: 100%;
  display: block;
  margin-left: auto;
  margin-right: auto;

  ${ContainerMaxWidth};
  
`;
