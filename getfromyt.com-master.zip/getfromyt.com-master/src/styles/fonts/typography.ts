import { Typography } from "../interfaces/interfaces";

export const typography: Typography = {
  primary: "'PT Sans', sans-serif",
  secondary: "'PT Sans Caption', sans-serif",
  tertiary: "",
};
