import { requests } from "./requestServices";

interface NotificationMessage {
  action: string;
  result: string;
  stackTraceOrErrorMessage?: string;
}

export class NotificationService {
  public static notifyServerAboutCertainActions(params: NotificationMessage) {
    return requests.post("notify-realtime-result", params);
  }
}
