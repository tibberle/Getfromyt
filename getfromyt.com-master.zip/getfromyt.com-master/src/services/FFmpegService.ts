import { createFFmpeg, fetchFile, FFmpeg } from "@ffmpeg/ffmpeg";
import { Nullable } from "../types/global-types";
import { FileNameUtil } from "../utils/FileNameUtil";
import { Observable, Subscriber } from "rxjs";
import { NotificationService } from "./NotificationService";

const passUsefulInformationToSubscriber =
  (subscriber: Subscriber<string>) =>
  ({ type, message }: any) => {
    if (
      !message.includes("configuration") &&
      !message.includes("run ffmpeg command") &&
      !message.includes("ffmpeg version") &&
      !message.includes("built with") &&
      !message.includes("libavutil") &&
      !message.includes("libavcodec") &&
      !message.includes("libavformat") &&
      !message.includes("libavdevice") &&
      !message.includes("libavfilter") &&
      !message.includes("libswscale") &&
      !message.includes("libswresample") &&
      !message.includes("libpostproc")
    ) {
      subscriber.next(message);
    }
  };

export class FFmpegService {
  private static ffmpeg: Nullable<FFmpeg> = null;

  public static async initializeFFmpeg(): Promise<void> {
    if (this.ffmpeg?.isLoaded) return;

    this.ffmpeg = createFFmpeg({ log: true });
    await this.ffmpeg.load();
  }

  public static isReady(): boolean {
    return Boolean(this.ffmpeg?.isLoaded);
  }

  public static async writeFileByUrl(params: {
    fileName: string;
    url: string;
  }): Promise<void> {
    if (!this.ffmpeg?.isLoaded) return;

    const { fileName, url } = params;

    return this.ffmpeg.FS("writeFile", fileName, await fetchFile(url));
  }

  public static readFile(fileName: string) {
    try {
      return this.ffmpeg?.FS("readFile", fileName);
    } catch {
      return undefined;
    }
  }

  public static async joinVideoAndAudio(params: {
    videoFileName: string;
    audioFileName: string;
    outputFileName: string;
  }) {
    const { audioFileName, videoFileName, outputFileName } = params;

    if (!this.ffmpeg?.isLoaded) return null;

    try {
      await this.ffmpeg.run(
        "-i",
        videoFileName,
        "-i",
        audioFileName,
        "-c",
        "copy",
        outputFileName
      );

      return true;
    } catch (error) {
      return false;
    }
  }

  public static async splitVideoAndAudio(fileName: string): Promise<boolean> {
    if (!this.ffmpeg?.isLoaded || !this.readFile(fileName)) return false;

    return new Promise((res) => {
      let log = "";
      const streaming = new Observable<string>((subscriber) => {
        this.ffmpeg!.setLogger(passUsefulInformationToSubscriber(subscriber));
        this.ffmpeg!.run(
          "-i",
          fileName,
          "-vn",
          "-c:a",
          "copy",
          FileNameUtil.getAudioOnlyFileName(fileName, "m4a")
        ).then(() => {
          this.ffmpeg!.run(
            "-i",
            fileName,
            "-an",
            "-c:v",
            "copy",
            FileNameUtil.getVideoOnlyFileName(fileName)
          ).then(() => {
            subscriber.complete();
          });
        });
      });

      streaming.subscribe(
        (logMessage) => (log += `${logMessage} \n`),
        undefined,
        () => {
          const audioOnlyFile = this.readFile(
            FileNameUtil.getAudioOnlyFileName(fileName, "m4a")
          );
          const videoOnlyFile = this.readFile(
            FileNameUtil.getVideoOnlyFileName(fileName)
          );

          if (!audioOnlyFile || !videoOnlyFile) {
            NotificationService.notifyServerAboutCertainActions({
              action: "Splitting Youtube Into Audio And Video",
              result: "FAIL",
              stackTraceOrErrorMessage: log,
            });
            res(false);
          } else {
            NotificationService.notifyServerAboutCertainActions({
              action: "Splitting Youtube Into Audio And Video",
              result: "SUCCESS",
            });
            res(true);
          }
        }
      );
    });
  }

  public static async cutAudio(params: {
    fileName: string;
    outputFileName: string;
    start: string;
    end: string;
  }): Promise<boolean> {
    if (!this.ffmpeg?.isLoaded) return false;

    return new Promise((res) => {
      let log = "";
      const { fileName, outputFileName, start, end } = params;

      const streaming = new Observable<string>((subscriber) => {
        this.ffmpeg!.setLogger(passUsefulInformationToSubscriber(subscriber));
        this.ffmpeg!.run(
          "-ss",
          start,
          "-to",
          end,
          "-i",
          fileName,
          "-c",
          "copy",
          outputFileName
        ).then(() => subscriber.complete());
      });

      streaming.subscribe(
        (logMessage) => (log += `${logMessage} \n`),
        undefined,
        () => {
          const outputFile = this.readFile(outputFileName);

          if (!outputFile) {
            NotificationService.notifyServerAboutCertainActions({
              action: "Cut Audio",
              result: "FAIL",
              stackTraceOrErrorMessage: log,
            });
            res(false);
          } else {
            NotificationService.notifyServerAboutCertainActions({
              action: "Cut Audio",
              result: "SUCCESS",
            });
            res(true);
          }
        }
      );
    });
  }

  public static async cutFile(params: {
    fileName: string;
    outputFileName: string;
    start: string;
    end: string;
    duration?: string;
  }): Promise<Nullable<boolean>> {
    if (!this.ffmpeg?.isLoaded) return null;

    return new Promise((res) => {
      let log = "";
      const { fileName, outputFileName, start, end, duration } = params;

      const streaming = new Observable<string>((subscriber) => {
        this.ffmpeg!.setLogger(passUsefulInformationToSubscriber(subscriber));

        const commands = ["-ss", start];

        if (!duration) {
          commands.push("-to", end);
        } else {
          commands.push("-t", duration);
        }

        commands.push("-i", fileName, "-c", "copy", outputFileName);

        this.ffmpeg!.run(...commands).then(() => subscriber.complete());
      });

      streaming.subscribe(
        (logMessage) => (log += `${logMessage} \n`),
        undefined,
        () => {
          const outputFile = this.readFile(outputFileName);

          if (!outputFile) {
            NotificationService.notifyServerAboutCertainActions({
              action: "Cut Video",
              result: "FAIL",
              stackTraceOrErrorMessage: log,
            });
            res(false);
          } else {
            NotificationService.notifyServerAboutCertainActions({
              action: "Cut Video",
              result: "SUCCESS",
            });
            res(true);
          }
        }
      );
    });
    // try {
    //   const { fileName, outputFileName, start, end, duration } = params;

    //   const fileCut = this.ffmpeg.FS("readFile", outputFileName);

    //   return new File([fileCut.buffer], outputFileName);
    // } catch (error) {
    //   return null;
    // }
  }
}
