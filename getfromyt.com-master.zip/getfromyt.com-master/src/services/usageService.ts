import dayjs, { Dayjs } from "dayjs";

const LOCALSTORAGE_KEY_NAME = "UsageCounting";

interface UsageCount {
  count: number;
  date: Dayjs;
}
export const getNumberOfUsageForToday = (): number => {
  if (!globalThis.localStorage) {
    return 0;
  }
  const storedUsageCount = globalThis.localStorage.getItem(
    LOCALSTORAGE_KEY_NAME
  );
  const today = dayjs();

  if (!storedUsageCount) {
    globalThis.localStorage.setItem(
      LOCALSTORAGE_KEY_NAME,
      JSON.stringify({ count: 0, date: today })
    );
    return 0;
  }

  const usageCount = JSON.parse(storedUsageCount) as UsageCount;
  const storedDate = dayjs(usageCount.date);

  if (!today.isSame(storedDate, "date")) {
    globalThis.localStorage.setItem(
      LOCALSTORAGE_KEY_NAME,
      JSON.stringify({ count: 0, date: today })
    );
    return 0;
  }

  return usageCount.count;
};

export const setNumberOfUsageForToday = (numberOfTimeUsed: number) => {
  if (!globalThis.localStorage) {
    return 0;
  }
  
  const storedUsageCount = globalThis.localStorage.getItem(
    LOCALSTORAGE_KEY_NAME
  );
  const today = dayjs();

  if (!storedUsageCount) {
    return globalThis.localStorage.setItem(
      LOCALSTORAGE_KEY_NAME,
      JSON.stringify({ count: numberOfTimeUsed, date: today })
    );
  }

  const usageCount = JSON.parse(storedUsageCount) as UsageCount;

  return localStorage.setItem(
    LOCALSTORAGE_KEY_NAME,
    JSON.stringify({ ...usageCount, count: numberOfTimeUsed })
  );
};
