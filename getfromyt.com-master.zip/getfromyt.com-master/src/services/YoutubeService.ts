import { Youtube } from "../Models/Youtube";
import { requests } from "./requestServices";

export class YoutubeService {
  public static downloadYoutubeById(id: string): Promise<Youtube> {
    return requests.post("youtube/download", { id });
  }
}
