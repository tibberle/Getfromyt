import { CuttingModel } from "../Models/Cutting";
import { DownloadInfoModel } from "../Models/DownloadInfo";
import { Youtube } from "../Models/Youtube";
import { requests } from "./requestServices";

type DownloadInfo = Omit<DownloadInfoModel, "title">;

export class VideoProcessorService {
  public static extractAudio(id: string): Promise<DownloadInfo> {
    return requests.post(`video-processor/extract-audio/${id}`, {});
  }

  public static cutAudio(params: CuttingModel): Promise<DownloadInfo> {
    return requests.post("video-processor/cut-audio", params);
  }

  public static cutVideo(params: CuttingModel): Promise<DownloadInfo> {
    return requests.post("video-processor/cut-video", params);
  }
}
