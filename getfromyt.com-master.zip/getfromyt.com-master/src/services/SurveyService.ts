import { requests } from "./requestServices";

export class SurveySurvice {
  public static submitAnswer(answers: string[], otherIdeas: string) {
    return requests.post(
      process.env.NEXT_PUBLIC_SURVEY_URL ?? "http://localhost:3000/api/survey",
      { answers, otherIdeas }
    );
  }
}
