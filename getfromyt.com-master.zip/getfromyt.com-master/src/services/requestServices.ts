import axios, { AxiosResponse } from "axios";

axios.defaults.baseURL = process.env.NEXT_PUBLIC_SERVER_URL
  ? `${process.env.NEXT_PUBLIC_SERVER_URL}`
  : `http://localhost:5000`;

const responseBody = (response: AxiosResponse) => response?.data;

axios.interceptors.request.use(
  (config) => {
    // const token = window.localStorage.getItem(TOKEN_KEY)
    // if (token) config.headers.Authorization = `Bearer ${token}`
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

axios.interceptors.response.use(undefined, (error) =>
  Promise.reject(error.response.data)
);

export const requests = {
  get: (url: string, params?: any) => axios.get(url, params).then(responseBody),
  post: (url: string, body: {}) => axios.post(url, body).then(responseBody),
  put: (url: string, body: {}) => axios.put(url, body).then(responseBody),
  del: (url: string) => axios.delete(url).then(responseBody),
};

export class RequestService {
  public static downloadFile({ url, title }: { url: string; title: string }) {
    return axios
      .get(url, { responseType: "blob" })
      .then(responseBody)
      .then((unitArray) => new File([unitArray], title));
  }
}
