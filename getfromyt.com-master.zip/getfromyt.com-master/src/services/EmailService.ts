import axios from "axios";

export class EmailService {
  public static send(params: {
    name: string;
    email: string;
    message: string;
  }): Promise<void> {
    return axios.post(process.env.NEXT_PUBLIC_EMAIL_URL ?? "http://localhost:3000/api/contact", params);
  }
}
