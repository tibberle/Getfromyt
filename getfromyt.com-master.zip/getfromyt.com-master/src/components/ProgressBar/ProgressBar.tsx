import styled from "@emotion/styled";
import React from "react";

export const StyledProgressbar = styled.div`
  background-color: #2196f3;
  border-radius: 3px;
  box-shadow: none;
  &.progress-xs {
    height: 5px;
    margin-top: 5px;
  }
  &.progress-sm {
    height: 10px;
    margin-top: 5px;
  }
  &.progress-lg {
    height: 25px;
  }
  &.vertical {
    position: relative;
    width: 20px;
    height: 200px;
    display: inline-block;
    margin-right: 10px;
    > .progress-bar {
      width: 100% !important;
      position: absolute;
      bottom: 0;
    }
    &.progress-xs {
      width: 5px;
      margin-top: 5px;
    }
    &.progress-sm {
      width: 10px;
      margin-top: 5px;
    }
    &.progress-lg {
      width: 30px;
    }
  }

  background-image: linear-gradient(
    45deg,
    rgba(255, 255, 255, 0.15) 25%,
    transparent 25%,
    transparent 50%,
    rgba(255, 255, 255, 0.15) 50%,
    rgba(255, 255, 255, 0.15) 75%,
    transparent 75%,
    transparent
  );
  background-size: 40px 40px;

  @keyframes progress-bar-stripes {
    from {
      background-position: 40px 0;
    }
    to {
      background-position: 0 0;
    }
  }

  animation: progress-bar-stripes 2s linear infinite;
  width: 100%;
  color: white;
  text-align: center;
  padding: 9px;
`;

interface Props {
  status: string;
}

export const ProgressBar: React.FC<Props> = ({ status }) => {
  return (
    <StyledProgressbar>
      <span>{status}</span>
    </StyledProgressbar>
  );
};
