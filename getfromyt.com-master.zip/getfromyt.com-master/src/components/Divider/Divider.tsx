import { css } from "@emotion/react";
import React from "react";
import { StyledDivider } from "./Divider.style";

export interface DividerProps {}

export const Divider: React.FunctionComponent<DividerProps> = (props) => {
  return <StyledDivider {...props} />;
};
