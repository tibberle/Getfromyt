import styled from "@emotion/styled";

export const StyledDivider = styled.hr`
  border: 2px solid ${({ theme }) => theme.backgroundColor.secondary};
  width: 100%;
  margin: 0;
`;
