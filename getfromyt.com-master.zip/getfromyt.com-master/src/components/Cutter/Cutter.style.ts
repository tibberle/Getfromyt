import { css } from "@emotion/react";
import styled from "@emotion/styled";
import {
  DEFAULT_SPACING_REM,
  EXTRA_LARGE_SPACING_REM,
  EXTRA_SMALL_SPACING_REM,
  LARGE_SPACING_REM,
  SMALL_SPACING_REM,
} from "../../styles/globalStyleConstants";

export const StyledCutter = styled.div`
  padding-bottom: ${DEFAULT_SPACING_REM}rem;
  padding-left: ${EXTRA_LARGE_SPACING_REM}rem;
  padding-right: ${EXTRA_LARGE_SPACING_REM}rem;
  line-height: 2.2rem;
  display: flex;
  flex-direction: column;
  width: 100%;
  
`;

export const StyledCutterPreviewer = styled.div`
  width: 100%;
  height:600px;
  @media (max-width: 875px) {
    height:500px;
    }
    @media (max-width: 700px) {
      height:400px;
    }
    @media (max-width: 550px) {
      height:300px;
    }
    @media (max-width: 430px) {
      height: 250px;
    }
  
`;

export const StyledCutterController = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: ${LARGE_SPACING_REM}rem;
  align-items: center;
  @media (max-width: 650px) {
    flex-direction: column;
    }
`;

export const StyledCutterControllerContainer = styled.div`
  min-width: 25%;
  display: flex;
  flex-direction: column;
`;

export const StyledCutterGroupButton = styled.div`
  display: flex;
  margin-bottom: ${SMALL_SPACING_REM}rem;

`;

export const StyledCutterTimeBox = styled.div`
  display: flex;
  align-items: center;
  @media (max-width: 650px) {
    margin: ${EXTRA_SMALL_SPACING_REM}rem 0;
    }

 
`;
export const StyledCutterDuration = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;
export const StyledCutterStartEnd = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  margin-right: ${LARGE_SPACING_REM}rem;
  
`;
