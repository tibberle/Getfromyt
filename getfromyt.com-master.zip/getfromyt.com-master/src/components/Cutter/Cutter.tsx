/** @jsxImportSource @emotion/react */
import React from "react";
import {
  StyledCutter,
  StyledCutterController,
  StyledCutterControllerContainer,
  StyledCutterDuration,
  StyledCutterGroupButton,
  StyledCutterPreviewer,
  StyledCutterStartEnd,
  StyledCutterTimeBox,
} from "./Cutter.style";
import { Typography } from "../Typography/Typography";
import { Button } from "../Button/Button";
import { IconButton } from "../IconButton/IconButton";
import Icon from "../Icon/Icon";
import { Cut32, Preview32 } from "../Icon/Icons";
import { css } from "@emotion/react";
import { DEFAULT_SPACING_REM } from "../../styles/globalStyleConstants";
import {
  formatMillisecondToHHMMSSXX,
  millisecondToHHMMSSXX,
} from "../../utils/timeUtils";
import YoutubePlayer from "youtube-player";
import { YouTubePlayer } from "youtube-player/dist/types";
import { RangeSlider } from "../RangeSlider/RangeSlider";
import { toast } from "react-toastify";
import { useRecoilState, useRecoilValue, useRecoilValueLoadable } from "recoil";
import { youtubeTypeState } from "../../stores/YoutubeTypeState";
import { YoutubeType } from "../../Models/Youtube";
import { usePage } from "../../utils/usePage";
import { cuttingDetailState } from "../../stores/cutterState";
import { youtubeState } from "../../stores/YoutubeState";

export interface CutterProps {}

export const Cutter: React.FunctionComponent<CutterProps> = () => {
  const { contents } = useRecoilValueLoadable(youtubeState);
  const youtubeType = useRecoilValue(youtubeTypeState);
  const [cutterTime, setCutterTime] = useRecoilState(cuttingDetailState);
  const { pageName } = usePage();
  const [startTime, setStartTime] = React.useState<number>(1);
  const [endTime, setEndTime] = React.useState<number>(0);
  const [totalTime, setTotalTime] = React.useState<number>();
  const previewerRef = React.useRef<HTMLDivElement>(null);
  const playerRef = React.useRef<YouTubePlayer>();

  const youtubeId = contents?.id;

  const createPlayer = async () => {
    if (!document || !previewerRef.current?.id || !youtubeId) return;

    playerRef.current = YoutubePlayer(previewerRef.current.id, {
      videoId: youtubeId,
    });

    const totalTime = (await getTotalTime()) ?? 0;

    setTotalTime(totalTime);

    setEndTime(totalTime - 1);
    playVideo();
  };

  React.useEffect(() => {
    if (!previewerRef || !youtubeId) return;

    createPlayer();

    return () => playerRef.current?.destroy();
  }, [youtubeId, cutterTime]);

  if (!youtubeId || pageName !== "CutterPage" || cutterTime) return null;

  const setCurrentDurationToStartTime = async () => {
    if (!playerRef.current) return;

    const player = playerRef.current;
    const currentTime = await Promise.resolve(player.getCurrentTime());
    setStartTime(currentTime);
  };

  const setCurrentDurationToEndTime = async () => {
    if (!playerRef.current) return;
    const player = playerRef.current;
    const currentTime = await Promise.resolve(player.getCurrentTime());
    setEndTime(currentTime);
  };

  const playVideo = () => {
    playerRef.current?.playVideo();
  };

  const pauseVideo = () => {
    playerRef.current?.pauseVideo();
  };

  const getTotalTime = async () => {
    const totalTime = await Promise.resolve(playerRef.current?.getDuration());
    return totalTime;
  };

  const playFromStartToEndTime = () => {
    if (!playerRef.current) return;

    if (endTime - startTime <= 0) {
      return toast.error("Invalid Cut Time!");
    }

    const player = playerRef.current;

    player.seekTo(startTime, true);

    playVideo();

    const interval = setInterval(async () => {
      const currentTime = await Promise.resolve(player.getCurrentTime());

      if (currentTime > endTime) {
        pauseVideo();
        clearInterval(interval);
      }
    }, 100);
  };

  const handleChangeTime = (value: number[]) => {
    setStartTime(value[0]);
    setEndTime(value[1]);
  };

  const onSubmitCutVideo = () => {
    if (endTime - startTime <= 0) {
      return toast.error("Invalid Cut Time!");
    }

    const startInMilliSeconds = Number((startTime * 1000).toFixed(3));
    const endInMilliSeconds = Number((endTime * 1000).toFixed(3));
    setCutterTime({
      startInMilliSeconds,
      endInMilliSeconds,
    });
  };

  const formattedStartTime = formatMillisecondToHHMMSSXX(
    millisecondToHHMMSSXX(startTime * 1000)
  );

  const formattedEndTime = formatMillisecondToHHMMSSXX(
    millisecondToHHMMSSXX(endTime * 1000)
  );

  const formattedCutTime = formatMillisecondToHHMMSSXX(
    millisecondToHHMMSSXX((endTime - startTime) * 1000)
  );

  const formattedTotalTime = formatMillisecondToHHMMSSXX(
    millisecondToHHMMSSXX((totalTime ?? 0) * 1000)
  );

  const exportType = youtubeType === YoutubeType.Video ? "Video" : "Audio";

  return (
    <StyledCutter>
      <StyledCutterPreviewer id="_video_previewer" ref={previewerRef} />
      <RangeSlider
        maxValue={totalTime}
        onChange={handleChangeTime}
        value={[startTime, endTime]}
      />
      <StyledCutterController>
        <StyledCutterControllerContainer>
          <StyledCutterGroupButton>
            <Button
              css={css`
                margin-right: ${DEFAULT_SPACING_REM}rem;
              `}
              size="small"
              onClick={setCurrentDurationToStartTime}
            >
              Start
            </Button>
            <Button
              size="small"
              color="error"
              onClick={setCurrentDurationToEndTime}
            >
              End
            </Button>
          </StyledCutterGroupButton>
          <StyledCutterTimeBox>
            <StyledCutterStartEnd>
              <Typography tag="p">
                <strong>Start:</strong>
              </Typography>
              <Typography tag="p">
                <strong>End:</strong>
              </Typography>
            </StyledCutterStartEnd>
            <StyledCutterDuration>
              <Typography tag="p">{formattedStartTime}</Typography>
              <Typography tag="p">{formattedEndTime}</Typography>
            </StyledCutterDuration>
          </StyledCutterTimeBox>
        </StyledCutterControllerContainer>
        <StyledCutterTimeBox>
          <IconButton
            shape="rounded"
            css={css`
              margin-right: ${DEFAULT_SPACING_REM}rem;
            `}
            onClick={playFromStartToEndTime}
          >
            <Icon data={Preview32} />
          </IconButton>
          <IconButton
            shape="rounded"
            onClick={onSubmitCutVideo}
            color="success"
          >
            <Icon data={Cut32} />
          </IconButton>
        </StyledCutterTimeBox>
        <StyledCutterControllerContainer>
          <StyledCutterTimeBox
            css={css`
              justify-content: flex-end;
            `}
          >
            <StyledCutterStartEnd>
              <Typography tag="p">
                <strong>Export Type:</strong>
              </Typography>
              <Typography tag="p">
                <strong>Total Duration:</strong>
              </Typography>
              <Typography tag="p">
                <strong>Cut Duration:</strong>
              </Typography>
            </StyledCutterStartEnd>
            <StyledCutterDuration>
              <Typography tag="p">{exportType}</Typography>
              <Typography tag="p">{formattedTotalTime}</Typography>
              <Typography tag="p">{formattedCutTime}</Typography>
            </StyledCutterDuration>
          </StyledCutterTimeBox>
        </StyledCutterControllerContainer>
      </StyledCutterController>
    </StyledCutter>
  );
};
