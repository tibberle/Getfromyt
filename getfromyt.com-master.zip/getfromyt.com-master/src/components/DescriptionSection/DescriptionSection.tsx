/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import React from "react";
import {
  EXTRA_LARGE_SPACING_REM,
  SMALL_SPACING_REM,
} from "../../styles/globalStyleConstants";
import { theme } from "../../styles/theme";
import { Paper } from "../Paper/Paper";
import { Typography } from "../Typography/Typography";
import {
  StyledDescriptionSectionAdSection,
  StyledDescriptionSectionMainSection,
} from "./DescriptionSection.style";
import ReactHtmlParser from "react-html-parser";

export interface DescriptionSectionProps {
  adId?: string;
  title?: JSX.Element;
  contents: Array<{
    content: string[];
    title: string;
    titleHtmlTag: any;
  }>;
}

export const DescriptionSection: React.FunctionComponent<DescriptionSectionProps> =
  ({ adId, title, contents }) => {
    return (
      <Paper
        css={css`
          flex-direction: row;
          padding: ${EXTRA_LARGE_SPACING_REM}rem;
          @media (min-width: 1024px) {
            max-width: 1024px;
            background-color: ${theme.backgroundColor.primary};
          }
        `}
      >
        <StyledDescriptionSectionMainSection>
          {title && (
            <Typography
              variant="h1"
              tag="h1"
              css={css`
                margin: 0 auto;
                margin-bottom: ${SMALL_SPACING_REM}rem;
              `}
            >
              {title}
            </Typography>
          )}
          {contents.map(({ content, title, titleHtmlTag = "h3" }, index) => (
            <section key={index}>
              <Typography
                variant="h3"
                tag={titleHtmlTag}
                key={title}
                css={css`
                  margin-top: ${SMALL_SPACING_REM}rem !important;
                `}
              >
                {ReactHtmlParser(title)}
              </Typography>
              {content.map((data) => (
                <Typography tag="p" key={data}>
                  {ReactHtmlParser(data)}
                </Typography>
              ))}
            </section>
          ))}
        </StyledDescriptionSectionMainSection>
        {adId && <StyledDescriptionSectionAdSection id={adId} />}
      </Paper>
    );
  };
