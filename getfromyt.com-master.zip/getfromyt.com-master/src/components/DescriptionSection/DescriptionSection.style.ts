import styled from "@emotion/styled";
import { EXTRA_LARGE_SPACING_REM } from "../../styles/globalStyleConstants";

export const StyledDescriptionSectionMainSection = styled.main`
  width: 100%;
  display: flex;
  flex-direction: column;
  /* margin-right: ${EXTRA_LARGE_SPACING_REM}rem; */
  
`;

export const StyledDescriptionSectionAdSection = styled.div`
  width: 500px;
`;
