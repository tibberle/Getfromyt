import { css } from "@emotion/react";
import { DEFAULT_SPACING_REM } from "../../styles/globalStyleConstants";

export const StyleInfoCard = css`
  padding: ${DEFAULT_SPACING_REM}rem;
  margin-bottom: ${DEFAULT_SPACING_REM}rem;
`;
