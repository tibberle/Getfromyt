/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import React from "react";
import { theme } from "../../styles/theme";
import { Paper } from "../Paper/Paper";
import { Typography } from "../Typography/Typography";
import { StyleInfoCard } from "./InfoCard.style";

export interface InfoCardProps {
  title: string;
  subTitle: string;
  descriptions: JSX.Element[];
}

export const InfoCard: React.FunctionComponent<InfoCardProps> = ({
  title,
  subTitle,
  descriptions,
}) => {
  return (
    <Paper outline css={StyleInfoCard}>
      <Typography
        tag="h2"
        variant="h5"
        css={css`
          margin: 0;
        `}
      >
        <strong>{title}</strong>
      </Typography>
      <Typography
        tag="p"
        variant="helper"
        css={css`
          color: ${theme.textColor.tertiary};
        `}
        block
      >
        {subTitle}
      </Typography>
      {descriptions.map((description) => (
        <Typography tag="p" variant="paragraph">
          {description}
        </Typography>
      ))}
    </Paper>
  );
};
