import React from "react";
import { Logo } from "../Logo/Logo";
import { NavItem } from "../NavItem/NavItem";
import {
  StyledHeaderNavbar,
  StyledHeaderNavbarWrapper,
  StyledNavbar,
} from "./HeaderNavbar.style";

export interface HeaderNavbarProps {}

export const HeaderNavbar: React.FunctionComponent<HeaderNavbarProps> = () => {
  return (
    <StyledHeaderNavbar>
      <StyledHeaderNavbarWrapper>
        <Logo />
        <StyledNavbar>
          <NavItem path="/" label="Home" />
          <NavItem path="/youtube-cutter" label="YouTube Cutter" />
          <NavItem path="/youtube-joiner" label="YouTube Merger" />
          <NavItem path="/news" label="News" />
        </StyledNavbar>
      </StyledHeaderNavbarWrapper>
    </StyledHeaderNavbar>
  );
};
