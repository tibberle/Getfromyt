import styled from "@emotion/styled";
import { ContainerMaxWidth } from "../../styles/common/Container";
import { EXTRA_LARGE_SPACING_REM, SMALL_SPACING_REM } from "../../styles/globalStyleConstants";
import { theme } from "../../styles/theme";

export const StyledHeaderNavbar = styled.header`
  padding: ${SMALL_SPACING_REM}rem 0;

  width: 100%;
  position: sticky;
  top: 0;
  z-index: 5;
  
  background-color: ${theme.backgroundColor.primary};

  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
`;

export const StyledHeaderNavbarWrapper = styled.div`
  ${ContainerMaxWidth};
  
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: auto;
  padding: 0 ${EXTRA_LARGE_SPACING_REM}rem;
  @media (max-width: 860px) {
    flex-direction: column;
    padding: 0;
  }
`;

export const StyledNavbar = styled.nav`
  margin: 0;
  padding: 0;
  justify-content: space-between;
  @media (max-width: 860px) {
    flex-direction: column;
    padding: 0;
  }
`;
