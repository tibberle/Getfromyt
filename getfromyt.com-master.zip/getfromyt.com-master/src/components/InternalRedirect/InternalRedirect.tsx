import React from "react";
import NextLink from "next/link";
import { StyledInternalRedirect } from "./InternalRedirect.style";

export interface InternalRedirectProps {
  path: string;
}

export const InternalRedirect: React.FunctionComponent<InternalRedirectProps> = ({
  path,
  children,
}) => {
  return (
    <NextLink href={path}>
      <StyledInternalRedirect>{children}</StyledInternalRedirect>
    </NextLink>
  );
};
