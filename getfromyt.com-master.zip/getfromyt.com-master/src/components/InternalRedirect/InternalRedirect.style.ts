import styled from "@emotion/styled";
import { StyledTypography } from "../Typography/Typography.style";

export const StyledInternalRedirect = styled(StyledTypography)`
  font-size: inherit;
  cursor: pointer;
  color: ${({ theme }) => theme.errorColor.primary};
`.withComponent("a");
