import {
  StyledTypography as Container,
  StyledTypographyProps,
} from "./Typography.style";

export type Tag = "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "p" | "span";

export interface TypographyProps {
  children: React.ReactNode;
  tag?: Tag;
}

export const Typography: React.FunctionComponent<
  TypographyProps & StyledTypographyProps
> = (props) => {
  const {
    children,
    variant = "paragraph",
    block = false,
    color = "default",
    tag = "span",
  } = props;
  const ContainerWithTag = Container.withComponent(tag);
  return (
    <ContainerWithTag variant={variant} block={block} color={color} {...props}>
      {children}
    </ContainerWithTag>
  );
};
