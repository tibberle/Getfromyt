import styled from "@emotion/styled";
import { Theme } from "../../styles/interfaces/interfaces";

export type VariantType =
  | "h1"
  | "h2"
  | "h3"
  | "h4"
  | "h5"
  | "paragraph"
  | "helper"
  | "copyright";

const getFontSizeByVariant = (variant: VariantType, theme: Theme): string => {
  switch (variant) {
    case "h1":
      return theme.typeScale.header1;
    case "h2":
      return theme.typeScale.header2;
    case "h3":
      return theme.typeScale.header3;
    case "h4":
      return theme.typeScale.header4;
    case "h5":
      return theme.typeScale.header5;
    case "helper":
      return theme.typeScale.helperText;
    case "copyright":
      return theme.typeScale.copyrightText;
    default:
      return theme.typeScale.paragraph;
  }
};

const getColor = (color: TypographyColor, theme: Theme): string => {
  switch (color) {
    case "reverse":
      return theme.backgroundColor.primary;
    case "inherit":
      return "inherit";

    default:
      return theme.textColor.primary;
  }
};

const getFontWeight = (variant: VariantType): number => {
  switch (variant) {
    case "helper":
      return 500;
    case "copyright":
      return 500;
    case "h1":
      return 700;
    case "h2":
      return 700;
    case "h3":
      return 700;
    case "h4":
      return 500;
    case "h5":
      return 500;

    default:
      return 500;
  }
};

type TypographyColor = "default" | "reverse" | "inherit";

export interface StyledTypographyProps {
  //   tag: "h1" | "h2" | "h3" | "h4" | "h5" | "p" | "span";
  variant?: VariantType;
  block?: boolean;
  color?: TypographyColor;
}

export const StyledTypography = styled.span<StyledTypographyProps>`
  font-size: ${({ variant, theme }) => getFontSizeByVariant(variant!, theme)};
  color: ${({ color, theme }) => getColor(color!, theme)};
  ${({ block }) => block && "display: block"};
  font-family: ${({ theme }) => theme.typography.primary};
  font-weight: ${({ variant }) => getFontWeight(variant!)};
  letter-spacing: 0.04rem;
  line-height: 1.5rem;
`;
