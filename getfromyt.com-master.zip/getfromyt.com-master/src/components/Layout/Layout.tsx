import React from "react";
import { Container } from "../../styles/common/Container";
import { useDetectAdBlock } from "../../utils/useDetectAdBlock";
import { Banner } from "../Banner/Banner";
import { Footer } from "../Footer/Footer";
import { HeaderNavbar } from "../HeaderNavbar/HeaderNavbar";

interface Props {
  children: React.ReactNode;
}

export const Layout: React.FC<Props> = ({ children }) => {
  const { adBlockDetected } = useDetectAdBlock();

  return (
    <>
      <HeaderNavbar />
      <Container>
        {adBlockDetected && (
          <Banner text="We try our best to bring you the best download / cut speed. Please consider to disable your adblock to support us. <br/> Happy Downloading / Cutting! ＼(＾▽＾)／	" />
        )}
        {children}
      </Container>
      <Footer />
    </>
  );
};
