import React from "react";
import {
  IconButtonColor,
  IconButtonShape,
  IconButtonVariant,
  StyledIconButton,
} from "./IconButton.style";

export interface IconButtonProps {
  variant?: IconButtonVariant;
  shape?: IconButtonShape;
  color?: IconButtonColor;
  disabled?: boolean;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}

export const IconButton: React.FunctionComponent<IconButtonProps> = (props) => {
  const {
    children,
    variant = "default",
    shape = "default",
    color = "default",
    disabled,
    onClick,
  } = props;
  return (
    <StyledIconButton
      variant={variant}
      shape={shape}
      onClick={onClick}
      color={color}
      disabled={disabled}
      {...props}
    >
      {children}
    </StyledIconButton>
  );
};
