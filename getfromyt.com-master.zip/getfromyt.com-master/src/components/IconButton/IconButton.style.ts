import styled from "@emotion/styled";
import { Theme } from "../../styles/interfaces/interfaces";
import {
  DEFAULT_BORDER_RADIUS,
  DEFAULT_SPACING_REM,
  SMALL_SPACING_REM,
} from "../../styles/globalStyleConstants";
import { StyleButtonBase } from "../Button/Button.style";

export type IconButtonVariant = "default" | "reverse";

export type IconButtonShape = "default" | "rounded";

export type IconButtonColor =
  | "default"
  | "success"
  | "warning"
  | "error"
  | "text";

const getColorByColorType = (color: IconButtonColor, theme: Theme): string => {
  switch (color) {
    case "success":
      return theme.successColor.primary;
    case "error":
      return theme.errorColor.primary;
    case "warning":
      return theme.warningColor.primary;
    case "text":
      return theme.textColor.secondary;

    default:
      return theme.primaryColor.primary;
  }
};

interface IconButtonProps {
  variant: IconButtonVariant;
  shape: IconButtonShape;
  color: IconButtonColor;
}

export const StyledIconButton = styled.button<IconButtonProps>`
  ${StyleButtonBase};
  color: ${({ variant, color, theme }) =>
    variant === "default"
      ? theme.backgroundColor.primary
      : getColorByColorType(color, theme)};
  background-color: ${({ variant, color, theme }) =>
    variant === "default" ? getColorByColorType(color, theme) : "transparent"};
  padding: ${DEFAULT_SPACING_REM}rem;
  fill: currentColor;
  ${({ shape }) =>
    shape === "rounded"
      ? "border-radius: 50%"
      : `border-radius: ${DEFAULT_BORDER_RADIUS}px`};

  :hover {
    background-color: ${({ variant, color, theme }) =>
      variant === "default"
        ? "transparent"
        : getColorByColorType(color, theme)};
    color: ${({ variant, color, theme }) =>
      variant === "default"
        ? getColorByColorType(color, theme)
        : theme.backgroundColor.primary};
  }

  :disabled {
    cursor: auto;
    background-color: ${({ variant, theme }) =>
      variant === "default" ? theme.disabledColor.primary : "transparent"};
    color: ${({ variant, theme }) =>
      variant === "default"
        ? theme.backgroundColor.primary
        : theme.disabledColor.primary};
  }
`;
