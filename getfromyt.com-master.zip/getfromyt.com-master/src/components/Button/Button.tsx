import React from "react";
import {
  StyledButton,
  StyledButtonProps,
  StyledIconWrapper,
} from "./Button.style";
import { Typography } from "../Typography/Typography";

export interface ButtonProps {
  icon?: JSX.Element;
  disabled?: boolean;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  onDoubleClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  submitButton?: boolean;
}

export const Button: React.FunctionComponent<
  ButtonProps & StyledButtonProps
> = (props) => {
  const {
    children,
    icon,
    size = "default",
    variant = "default",
    disabled = false,
    color = "default",
    onClick,
    onDoubleClick,
    submitButton,
  } = props;
  return (
    <StyledButton
      type={submitButton ? "submit" : "button"}
      size={size}
      variant={variant}
      disabled={disabled}
      onClick={onClick}
      color={color}
      onDoubleClick={onDoubleClick}
      {...props}
    >
      <Typography color="inherit">{children}</Typography>
      {icon && <StyledIconWrapper>{icon}</StyledIconWrapper>}
    </StyledButton>
  );
};
