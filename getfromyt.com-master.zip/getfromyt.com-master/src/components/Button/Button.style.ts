import { css } from "@emotion/react";
import styled from "@emotion/styled";
import { theme } from "../../styles/theme";
import {
  DEFAULT_BORDER_RADIUS,
  DEFAULT_SPACING_REM,
  DEFAULT_TRANSITION_TIME,
  EXTRA_SMALL_SPACING_REM,
  LARGE_SPACING_REM,
  SMALL_SPACING_REM,
} from "../../styles/globalStyleConstants";

const getPaddingBySize = (size: ButtonSize): string => {
  switch (size) {
    case "big":
      return `${DEFAULT_SPACING_REM}rem ${LARGE_SPACING_REM}rem`;
    case "small":
      return `${EXTRA_SMALL_SPACING_REM}rem  ${LARGE_SPACING_REM}rem`;
    default:
      return `${SMALL_SPACING_REM}rem  ${LARGE_SPACING_REM}rem`;
  }
};

const getFontBySize = (size: ButtonSize): string => {
  switch (size) {
    case "big":
      return theme.typeScale.header5;
    case "small":
      return theme.typeScale.helperText;

    default:
      return theme.typeScale.paragraph;
  }
};

const getColor = (color: ButtonColor): string => {
  switch (color) {
    case "black":
      return theme.textColor.secondary;
    case "success":
      return theme.successColor.primary;
    case "error":
      return theme.errorColor.primary;
    default:
      return theme.primaryColor.primary;
  }
};

const getColorHover = (color: ButtonColor): string => {
  switch (color) {
    case "black":
      return theme.textColor.secondary;
    case "success":
      return theme.successColor.secondary;
    case "error":
      return theme.errorColor.secondary;
    default:
      return theme.primaryColor.secondary;
  }
};

const getColorActive = (color: ButtonColor): string => {
  switch (color) {
    case "black":
      return theme.textColor.tertiary;
    case "success":
      return theme.successColor.tertiary;
    case "error":
      return theme.errorColor.tertiary;
    default:
      return theme.primaryColor.tertiary;
  }
};

export const StyleButtonBase = css`
  border: none;
  outline: none;
  display: inline-flex;
  cursor: pointer;
  padding: 0;
  vertical-align: middle;
  text-decoration: none;
  background-color: transparent;
  align-items: center;
  justify-content: center;
  position: relative;
  transition: ${DEFAULT_TRANSITION_TIME}s ease all;
`;

export type ButtonSize = "default" | "big" | "small";

export type ButtonVariant = "default" | "outline" | "ghost";

export type ButtonColor = "default" | "black" | "success" | "error";

export interface StyledButtonProps {
  size?: ButtonSize;
  variant?: ButtonVariant;
  color?: ButtonColor;
}

export const StyledButton = styled.button<StyledButtonProps>`
  ${StyleButtonBase};
  background-color: ${({ variant, color }) =>
    variant === "default" ? getColor(color!) : "transparent"};
  ${({ variant }) =>
    variant === "outline" && `box-shadow: 0 0 0 1px inset currentColor`};

  padding: ${({ size }) => getPaddingBySize(size!)};
  color: ${({ variant, color, theme }) =>
    variant === "default" ? theme.backgroundColor.primary : getColor(color!)};
  fill: currentColor;
  border-radius: ${DEFAULT_BORDER_RADIUS}px;
  font-size: ${({ size }) => getFontBySize(size!)};
  text-transform: capitalize;

  :hover {
    background-color: ${({ variant, color, theme }) =>
      variant === "ghost"
        ? theme.backgroundColor.secondary
        : getColorHover(color!)};
    border-color: ${({ color }) => getColorHover(color!)};
    color: ${({ variant, color, theme }) =>
      variant === "ghost"
        ? getColorHover(color!)
        : theme.backgroundColor.secondary};
  }

  :active {
    background-color: ${({ variant, color, theme }) =>
      variant === "ghost"
        ? theme.backgroundColor.tertiary
        : getColorActive(color!)};
    border-color: ${({ variant, color, theme }) =>
      variant === "ghost"
        ? theme.backgroundColor.tertiary
        : getColorActive(color!)};
    color: ${({ variant, color }) =>
      variant === "ghost"
        ? getColorActive(color!)
        : theme.backgroundColor.tertiary};
  }

  :disabled {
    cursor: auto;
    color: ${({ variant, theme }) =>
      variant === "default"
        ? theme.backgroundColor.primary
        : theme.disabledColor.primary};
    background-color: ${({ variant, theme }) =>
      variant === "default" ? theme.disabledColor.primary : "transparent"};
    ${({ variant, theme }) =>
      variant === "outline" &&
      `box-shadow: 0 0 0 1px inset ${theme.backgroundColor.tertiary}`};
  }
`;

export const StyledIconWrapper = styled.div`
  padding-left: ${EXTRA_SMALL_SPACING_REM}rem;
  display: flex;
  justify-content: center;
  align-items: center;
`;
