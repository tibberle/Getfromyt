/** @jsxImportSource @emotion/react */
import React from "react";
import {
  StyledTextField,
  StyledTextFieldArea,
  StyledTextFieldInput,
  StyledTextFieldLabel,
  StyleFocusTextField,
} from "./TextField.style";

export interface TextFieldProps {
  label: string;
  placeholder?: string;
  textarea?: boolean;
  required?: boolean;
  onChange?: (updatedText: string) => void;
}

export const TextField: React.FunctionComponent<TextFieldProps> = ({
  placeholder,
  label,
  textarea,
  onChange,
  required = false,
}) => {
  const [focus, setFocus] = React.useState(false);

  return (
    <StyledTextField css={focus && StyleFocusTextField}>
      <StyledTextFieldLabel>
        {label} {required && "*"}
      </StyledTextFieldLabel>
      {textarea ? (
        <StyledTextFieldArea
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          placeholder={placeholder}
          rows={6}
          required={required}
          onChange={(e) => onChange?.(e.currentTarget.value)}
        />
      ) : (
        <StyledTextFieldInput
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          onChange={(e) => onChange?.(e.currentTarget.value)}
          placeholder={placeholder}
          required={required}
        />
      )}
    </StyledTextField>
  );
};
