import { css } from "@emotion/react";
import styled from "@emotion/styled";
import {
  DEFAULT_BORDER_RADIUS,
  DEFAULT_SPACING_REM,
  DEFAULT_TRANSITION_TIME,
  SMALL_SPACING_REM,
} from "../../styles/globalStyleConstants";
import { theme } from "../../styles/theme";

export const StyledTextField = styled.div`
  color: ${({ theme }) => theme.textColor.tertiary};
  border-radius: ${DEFAULT_BORDER_RADIUS}px;
  border: 1px solid currentColor;
  display: inline-flex;
  width: 100%;
  padding: ${DEFAULT_SPACING_REM}rem;
  position: relative;
  transition: ${DEFAULT_TRANSITION_TIME}s all ease;

  :hover {
    color: ${({ theme }) => theme.textColor.secondary};
  }
`;

export const StyledTextFieldLabel = styled.label`
  position: absolute;
  top: -10px;
  z-index: 5;
  background-color: white;
  padding: 0 ${SMALL_SPACING_REM}rem;
`;

export const StyledTextFieldInput = styled.input`
  padding: 0 ${SMALL_SPACING_REM}rem;
  outline: none;
  border: none;
  color: inherit;
  width: 100%;

  ::placeholder {
    color: ${({ theme }) => theme.textColor.tertiary};
  }
`;

export const StyledTextFieldArea = styled.textarea`
  padding: 0 ${SMALL_SPACING_REM}rem;
  outline: none;
  border: none;
  color: inherit;
  width: 100%;

  ::placeholder {
    color: ${({ theme }) => theme.textColor.tertiary};
  }
`;

export const StyleFocusTextField = css`
  color: ${theme.textColor.primary};
  :hover {
    color: ${theme.textColor.primary};
  }
`;
