import styled from "@emotion/styled";
import {
  DEFAULT_BORDER_RADIUS,
  DEFAULT_SPACING_REM,
  EXTRA_LARGE_SPACING_REM,
  EXTRA_SMALL_SPACING_REM,
  SMALL_SPACING_REM,
} from "../../styles/globalStyleConstants";

const StyledRoot = styled.section`
  display: flex;

  background-color: ${({ theme }) => theme.textColor.primary};

  color: ${({ theme }) => theme.white};
  padding: ${DEFAULT_SPACING_REM}rem ${EXTRA_LARGE_SPACING_REM}rem;
  margin-top: ${EXTRA_SMALL_SPACING_REM}rem;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
`;

export const StyledBanner = { StyledRoot };
