/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import React from "react";
import { StyledBanner } from "./Banner.style";
import ReactHtmlParser from "react-html-parser";
import Icon from "../Icon/Icon";
import { AdBlock40 } from "../Icon/Icons";

export interface BannerProps {
  text: string;
}

export const Banner: React.FunctionComponent<BannerProps> = ({ text }) => {
  const { StyledRoot } = StyledBanner;
  return (
    <StyledRoot>
      <Icon
        data={AdBlock40}
        css={css`
          margin-right: 1rem;
        `}
      />
      {ReactHtmlParser(text)}
    </StyledRoot>
  );
};
