import styled from "@emotion/styled";
import {
  EXTRA_LARGE_SPACING_REM,
  SMALL_SPACING_REM,
} from "../../styles/globalStyleConstants";

export const StyledDownloadSectionTitle = styled.div`
  margin-top: ${EXTRA_LARGE_SPACING_REM}rem;
  margin-bottom: ${SMALL_SPACING_REM}rem;
  text-transform: capitalize;
`;

export const StyledDownloadSectionDescription = styled.div`
  margin-bottom: ${EXTRA_LARGE_SPACING_REM}rem;
  text-transform: capitalize;
  color: ${({ theme }) => theme.textColor.secondary};
`;

export const StyledDownloadSectionTOS = styled.div`
  margin: ${EXTRA_LARGE_SPACING_REM}rem 0;
`;

export const StyledDownloadSectionNote = styled.div`
  margin: ${EXTRA_LARGE_SPACING_REM}rem 0;
  text-align: center;
`;

export const StyledDownloadSectionMaintenance = styled.div`
  width: 60%;
  text-align: center;
  margin-top: -${SMALL_SPACING_REM}rem;
`;
