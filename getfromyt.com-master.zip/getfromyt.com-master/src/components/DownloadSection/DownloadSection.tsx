/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import React from "react";
import {
  EXTRA_LARGE_SPACING_REM,
  LARGE_SPACING_REM,
} from "../../styles/globalStyleConstants";
import { Divider } from "../Divider/Divider";
import { Paper } from "../Paper/Paper";
import { Typography } from "../Typography/Typography";
import {
  StyledDownloadSectionDescription,
  StyledDownloadSectionMaintenance,
  StyledDownloadSectionNote,
  StyledDownloadSectionTitle,
  StyledDownloadSectionTOS,
} from "./DownloadSection.style";
import { theme } from "../../styles/theme";
import { MaintenanceData } from "../../static/Maintenance";
import ReactHtmlParser from "react-html-parser";
import { BrowserUtils } from "../../utils/BrowserUtils";

export interface DownloadSectionProps {
  note?: JSX.Element;
  title: string;
  description: string;
  downloadBar: JSX.Element;
  downloadInfo: JSX.Element;
  cutter?: JSX.Element;
  maintenance?: boolean;
}

export const DownloadSection: React.FunctionComponent<DownloadSectionProps> = ({
  note,
  title,
  description,
  downloadBar,
  downloadInfo,
  cutter,
  maintenance,
}) => {
  const renderTOS = () => (
    <StyledDownloadSectionTOS>
      <Typography variant="helper" tag="p">
        By using our service you are accepting our{" "}
        <a href="/terms-of-service" target="_blank">
          terms of use.
        </a>
      </Typography>
    </StyledDownloadSectionTOS>
  );

  if (process.env.NEXT_PUBLIC_MAINTENANCE === "true" || maintenance) {
    return (
      <header>
        <Paper
          css={css`
            margin-top: 4px;
            margin-bottom: ${LARGE_SPACING_REM}rem;
            align-items: center;
          `}
        >
          <StyledDownloadSectionTitle>
            <Typography
              variant="h1"
              css={css`
                font-family: ${theme.typography.secondary};
              `}
              tag="h1"
            >
              {title}
            </Typography>
          </StyledDownloadSectionTitle>
          <StyledDownloadSectionDescription>
            <Typography variant="h5" color="inherit" tag="h2">
              {description}
            </Typography>
          </StyledDownloadSectionDescription>
          <StyledDownloadSectionMaintenance>
            {/* {BrowserUtils.isMobile() ? (
              <Typography tag="p">
                We're having some trouble with mobile device at the moment.
                Please use getfromyt.com on the web or try again in 3 days,
                thanks.
              </Typography>
            ) : (
              MaintenanceData.map((data) => (
                <Typography tag="p" key={data}>
                  {ReactHtmlParser(data)}
                </Typography>
              ))
            )} */}
            {MaintenanceData.map((data) => (
              <Typography tag="p" key={data}>
                {ReactHtmlParser(data)}
              </Typography>
            ))}
          </StyledDownloadSectionMaintenance>
          <Divider
            css={css`
              margin-top: ${EXTRA_LARGE_SPACING_REM}rem;
            `}
          />
          {note && (
            <StyledDownloadSectionNote>{note}</StyledDownloadSectionNote>
          )}
        </Paper>
      </header>
    );
  }

  return (
    <>
      <header>
        <Paper
          css={css`
            margin-bottom: ${LARGE_SPACING_REM}rem;
            align-items: center;
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
          `}
        >
          <StyledDownloadSectionTitle>
            <Typography
              variant="h1"
              css={css`
                font-family: ${theme.typography.secondary};
                margin-bottom: 0;
              `}
              tag="h1"
            >
              {title}
            </Typography>
          </StyledDownloadSectionTitle>
          <StyledDownloadSectionDescription>
            <Typography variant="h5" color="inherit" tag="h2">
              {description}
            </Typography>
          </StyledDownloadSectionDescription>

          {downloadBar}
          {renderTOS()}
          {downloadInfo}
          {cutter}
          <Divider
            css={css`
              margin-top: ${EXTRA_LARGE_SPACING_REM}rem;
            `}
          />
          {note && (
            <StyledDownloadSectionNote>{note}</StyledDownloadSectionNote>
          )}
        </Paper>
      </header>
      <div id="in-place-ad-container"></div>
    </>
  );
};

export const Maintenance = [
  {
    titleHtmlTag: "h2",
    title: `Server Update!!!`,
    content: `The app is under maintenance, it will return to normal <strong>as soon as possible</strong>.
            Meanwhile you can have a check in our
            <a href="/news">News</a> and let see what we
            are doing :).`,
  },
  {
    content: `You can also contact us via
            <a href="/contact">Contact</a> to let us know
            your issues :).`,
  },
  { content: "Thanks for your patience." },
];
