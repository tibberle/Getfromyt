import { useRouter } from "next/router";
import React from "react";
import {
  useRecoilState,
  useRecoilValueLoadable,
  useResetRecoilState,
  useSetRecoilState,
} from "recoil";
import { YoutubeType } from "../../Models/Youtube";
import { audioExtractorState } from "../../stores/audioExtractorState";
import {
  audioCutterState,
  cuttingDetailState,
  videoCutterState,
} from "../../stores/cutterState";
import { youtubeIdState } from "../../stores/youtubeIdState";
import { youtubeSplitterState } from "../../stores/YoutubeSplitterState";
import { youtubeState } from "../../stores/YoutubeState";
import { youtubeTypeState } from "../../stores/YoutubeTypeState";
import { usePage } from "../../utils/usePage";
import { getYoutubeVideoId, isValidYoutubeUrl } from "../../utils/youtubeUtils";

export const useDownloadBar = () => {
  const { query } = useRouter();
  const { pageName } = usePage();
  const existedUrl =
    query.videoId && `https://www.youtube.com/watch?v=${query.videoId}`;

  const [url, setUrl] = React.useState<string>(existedUrl ?? "");

  const resetCutTime = useResetRecoilState(cuttingDetailState);

  const setYoutubeId = useSetRecoilState(youtubeIdState);

  const { state: gettingYoutubeStatus, contents: gettingYoutubeResult } =
    useRecoilValueLoadable(youtubeState);

  const { state: audioExtractorStatus } = useRecoilValueLoadable(
    audioExtractorState(pageName)
  );

  const { state: processingYoutubeStatus } =
    useRecoilValueLoadable(youtubeSplitterState);

  const { state: audioCuttingStatus } =
    useRecoilValueLoadable(audioCutterState);

  const { state: videoCuttingStatus } =
    useRecoilValueLoadable(videoCutterState);

  const [youtubeType, setYoutubeType] = useRecoilState(youtubeTypeState);

  const validYoutubeUrl = isValidYoutubeUrl(url);

  const handleChangeUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
    setYoutubeId(null);
    setUrl(e.currentTarget.value);
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    resetCutTime();
    const youtubeId = getYoutubeVideoId(url);
    if (youtubeId) {
      setYoutubeId(youtubeId);
    }
  };

  const handleYoutubeTypeChanged = (type: YoutubeType) => {
    setYoutubeType(type);
    resetCutTime();
  };

  const disabled =
    gettingYoutubeStatus === "loading" ||
    processingYoutubeStatus === "loading" ||
    audioExtractorStatus === "loading" ||
    audioCuttingStatus === "loading" ||
    videoCuttingStatus === "loading";

  React.useEffect(() => {
    if (query.videoId) {
      setUrl(`https://www.youtube.com/watch?v=${query.videoId}`);
    }
  }, [query.videoId]);

  React.useEffect(() => {
    if (!disabled && gettingYoutubeResult?.id && !youtubeType) {
      setYoutubeType(YoutubeType.Video);
    }
  }, [disabled, youtubeType]);

  return {
    models: {
      url,
      dirtyLink: url.length === 0,
      validYoutubeUrl,
      disabled,
      youtubeType,
    },
    operators: {
      handleChangeUrl,
      handleSubmit,
      onYoutubeTypeChanged: handleYoutubeTypeChanged,
    },
  };
};
