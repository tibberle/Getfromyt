/** @jsxImportSource @emotion/react */
import React from "react";
import { YoutubeType } from "../../Models/Youtube";

import { Button } from "../Button/Button";
import { useDownloadBar } from "./DownloadBar.logic";
import {
  StyledDownloadBar,
  StyledDownloadBarButton,
  StyledDownloadBarInput,
  StyledDownloadSectionRadioButton,
  StyledDownloadSectionTypeWrapper,
  StyleDownloadSectionActiveRadioButton,
} from "./DownloadBar.style";

export interface DownloadBarProps {}

export const DownloadBar: React.FunctionComponent<DownloadBarProps> = () => {
  const {
    models: { dirtyLink, url, validYoutubeUrl, disabled, youtubeType },
    operators: { handleChangeUrl, handleSubmit, onYoutubeTypeChanged },
  } = useDownloadBar();

  const renderRadioButton = () => {
    if (youtubeType === null) return null;

    return (
      <StyledDownloadSectionTypeWrapper>
        <StyledDownloadSectionRadioButton
          variant="outline"
          color="black"
          onClick={() => onYoutubeTypeChanged(YoutubeType.Video)}
          css={
            // @ts-ignore
            youtubeType === YoutubeType.Video &&
            StyleDownloadSectionActiveRadioButton
          }
          disabled={disabled}
        >
          Video (HD)
        </StyledDownloadSectionRadioButton>

        <StyledDownloadSectionRadioButton
          variant="outline"
          color="black"
          onClick={() => onYoutubeTypeChanged(YoutubeType.Audio)}
          css={
            youtubeType === YoutubeType.Audio &&
            StyleDownloadSectionActiveRadioButton
          }
          disabled={disabled}
        >
          Audio
        </StyledDownloadSectionRadioButton>
      </StyledDownloadSectionTypeWrapper>
    );
  };

  return (
    <>
      <StyledDownloadBar
        isValid={!dirtyLink ? validYoutubeUrl : true}
        disabled={disabled}
        onSubmit={handleSubmit}
      >
        <StyledDownloadBarInput
          placeholder="Please insert a valid video URL"
          value={url}
          onChange={handleChangeUrl}
          disabled={disabled}
        />
        <StyledDownloadBarButton>
          <Button
            disabled={dirtyLink || !validYoutubeUrl || disabled}
            submitButton={true}
          >
            Submit
          </Button>
        </StyledDownloadBarButton>
      </StyledDownloadBar>
      {renderRadioButton()}
    </>
  );
};
