import { css } from "@emotion/react";
import styled from "@emotion/styled";
import {
  DEFAULT_BORDER_RADIUS,
  DEFAULT_SPACING_REM,
  DEFAULT_TRANSITION_TIME,
  EXTRA_LARGE_SPACING_REM,
  EXTRA_SMALL_SPACING_REM,
  LARGE_SPACING_REM,
} from "../../styles/globalStyleConstants";
import { theme } from "../../styles/theme";
import { StyledButton } from "../Button/Button.style";

const downloadBarWidth = "60%" ;


export interface StyledDownloadbarProps {
  isValid?: boolean;
  disabled?: boolean;
}

export const StyledDownloadBar = styled.form<StyledDownloadbarProps>`
  display: flex;
  border: 6px solid
    ${({ theme, isValid, disabled }) =>
      disabled
        ? theme.disabledColor.primary
        : isValid
        ? theme.primaryColor.primary
        : theme.errorColor.primary};
  width: ${downloadBarWidth};
  border-radius: ${DEFAULT_BORDER_RADIUS}px;
  transition: ${DEFAULT_TRANSITION_TIME}s ease all;
  @media (max-width: 570px) {
    width:90%;
  }
`;

export const StyledDownloadBarInput = styled.input`
  border: none;
  outline: none;
  padding-left: ${LARGE_SPACING_REM}rem;
  width: 100%;

  font-size: ${theme.typeScale.helperText};
  :placeholder-shown {
    color: ${theme.textColor.tertiary};
  }
  :invalid {
    color: ${theme.errorColor.primary};
  }
`;

export const StyledDownloadBarButton = styled.div`
  margin: ${EXTRA_SMALL_SPACING_REM}rem;
`;

export const StyledDownloadSectionTypeWrapper = styled.div`
  margin-top: ${DEFAULT_SPACING_REM}rem;
  width: ${downloadBarWidth};
  display: flex;
  justify-content: space-between;
  @media (max-width: 570px) {
    width:90%;

  }
`;

export const StyledDownloadSectionRadioButton = styled(StyledButton)`
  width: 48.7%;

  :disabled {
    pointer-events: none;
  }
`;

export const StyleDownloadSectionActiveRadioButton = css`
  background-color: ${theme.textColor.tertiary};
  color: ${theme.backgroundColor.tertiary};

  :hover {
    background-color: ${theme.textColor.tertiary};
    color: ${theme.backgroundColor.tertiary};
  }

  :disabled {
    background-color: ${theme.disabledColor.primary};
    color: ${theme.backgroundColor.primary};
  }
`;
