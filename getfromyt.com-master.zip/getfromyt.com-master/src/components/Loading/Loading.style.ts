import styled from "@emotion/styled";

export const StyledLoadingImage = styled.img<{ center?: boolean }>`
  width: 100px;

  ${(props) =>
    props.center
      ? `
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  `
      : ""}
`;
