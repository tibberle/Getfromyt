import React from "react";
import { Typography } from "../Typography/Typography";
import { StyledLoadingImage } from "./Loading.style";

export interface LoadingProps {
  center?: boolean
}

export const Loading: React.FunctionComponent<LoadingProps> = ({
  children,
  center
}) => {
  return (
    <>
      <Typography variant="paragraph" tag="p">
        {children}
      </Typography>
      <StyledLoadingImage center={center} src="/loading.gif" alt="Loading progress" />
    </>
  );
};
