import styled from "@emotion/styled";
import { EXTRA_SMALL_SPACING_REM } from "../../styles/globalStyleConstants";
import { StyledButton } from "../Button/Button.style";

export const StyledNavItemWithDropdown = styled.div`
  position: relative;
`;

export const StyledNavItemWithDropdown_DropdownWrapper = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: auto;
  bottom: auto;
  transform: translate(0, 48px);
  display: flex;
  flex-direction: column;
`;

export const StyledNavItemWithDropdown_DropdownItem = styled(StyledButton)`
  margin-bottom: ${EXTRA_SMALL_SPACING_REM}rem;
`.withComponent("a");
