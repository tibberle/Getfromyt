import React from "react";
import { Button } from "../Button/Button";
import Icon from "../Icon/Icon";
import { ArrowDown24, ArrowUp24 } from "../Icon/Icons";
import {
  StyledNavItemWithDropdown,
  StyledNavItemWithDropdown_DropdownItem,
  StyledNavItemWithDropdown_DropdownWrapper,
} from "./NavItemWithDropdown.style";

export interface DropdownItem {
  label: string;
  path: string;
}

export interface NavItemWithDropdownProps {
  items: DropdownItem[];
}

export const NavItemWithDropdown: React.FunctionComponent<NavItemWithDropdownProps> = ({
  items,
}) => {
  const [openDropdown, setOpenDropdown] = React.useState<boolean>(false);

  const handleButtonClicked = () => {
    setOpenDropdown(!openDropdown);
  };

  const renderDropdownItem = (item: DropdownItem) => (
    <StyledNavItemWithDropdown_DropdownItem
      variant="outline"
      color="black"
      href={item.path}
    >
      {item.label}
    </StyledNavItemWithDropdown_DropdownItem>
  );

  return (
    <StyledNavItemWithDropdown>
      <Button
        color="black"
        variant="outline"
        onClick={handleButtonClicked}
        icon={<Icon data={openDropdown ? ArrowUp24 : ArrowDown24} />}
      >
        language
      </Button>
      {openDropdown && (
        <StyledNavItemWithDropdown_DropdownWrapper>
          {items.map(renderDropdownItem)}
        </StyledNavItemWithDropdown_DropdownWrapper>
      )}
    </StyledNavItemWithDropdown>
  );
};
