import { css } from "@emotion/react";
import styled from "@emotion/styled";
import {
  EXTRA_LARGE_SPACING_REM,
  SMALL_SPACING_REM,
} from "../../styles/globalStyleConstants";
import { theme } from "../../styles/theme";
import { StyledButton } from "../Button/Button.style";

export const StyledCustom404 = styled.div`
  padding: ${EXTRA_LARGE_SPACING_REM}rem;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const StyledCustom404DescriptionText = css`
  margin: 0;
  color: ${theme.textColor.secondary};
`;

export const StyledCustom404Image = styled.img`
  margin: ${EXTRA_LARGE_SPACING_REM}rem 0;
  width: 200px;
  @media (max-width: 750px) {
    width: 100%;
  }
`;

export const StyledCustom404Button = styled(StyledButton)`
  margin-bottom: ${SMALL_SPACING_REM}rem;
  width: 30%;
  @media (max-width: 750px) {
    width: 100%;
  }
  

  :nth-last-of-type(1) {
    margin: 0;
  }
`.withComponent("a");
