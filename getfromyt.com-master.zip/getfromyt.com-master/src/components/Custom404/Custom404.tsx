/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import React from "react";
import { EXTRA_SMALL_SPACING_REM } from "../../styles/globalStyleConstants";
import { Typography } from "../Typography/Typography";
import {
  StyledCustom404,
  StyledCustom404Button,
  StyledCustom404DescriptionText,
  StyledCustom404Image,
} from "./Custom404.style";

export interface Custom404Props {}

export const Custom404: React.FunctionComponent<Custom404Props> = () => {
  return (
    <StyledCustom404>
      <Typography tag="h1" variant="h1">
        404 - Page Not Found!!!
      </Typography>
      <Typography tag="h2" variant="h5" css={StyledCustom404DescriptionText}>
        Sorry, that's page can't be found
      </Typography>
      <StyledCustom404Image src="/not-found.png" alt="not found page" />
      <StyledCustom404Button
        color="black"
        size="big"
        variant="default"
        href="/contact"
      >
        <b>Ask For Help</b>
      </StyledCustom404Button>
      <StyledCustom404Button size="big" variant="default" href="/">
        <span
          css={css`
            margin-right: ${EXTRA_SMALL_SPACING_REM}rem;
          `}
        >
          Return To
        </span>{" "}
        <b>Home Page</b>
      </StyledCustom404Button>
    </StyledCustom404>
  );
};
