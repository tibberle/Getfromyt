import { toast } from "react-toastify";
import { useRecoilValueLoadable } from "recoil";
import { audioExtractorState } from "../stores/audioExtractorState";
import { audioCutterState, videoCutterState } from "../stores/cutterState";
import { youtubeState } from "../stores/YoutubeState";
import { usePage } from "../utils/usePage";

export const NotificationManager = () => {
  const { pageName } = usePage();

  const {
    state: fetchingYoutubeVideoStatus,
    contents: fetchingYoutubeVideoResult,
  } = useRecoilValueLoadable(youtubeState);

  const { state: audioExtratorStatus } = useRecoilValueLoadable(
    audioExtractorState(pageName)
  );

  const { state: audioCuttingStatus } =
    useRecoilValueLoadable(audioCutterState);

  const { state: videoCuttingStatus } =
    useRecoilValueLoadable(videoCutterState);

  if (fetchingYoutubeVideoStatus === "hasError") {
    if (fetchingYoutubeVideoResult.SourceOfError === "Youtube-dl")
      toast.error(fetchingYoutubeVideoResult.Message);
    else toast.error("Cannot download this video at the moment.");
  }

  if (audioExtratorStatus === "hasError") {
    toast.error("Failed to extract, please refresh the browser and try again");
  }

  if (audioCuttingStatus === "hasError") {
    toast.error(
      "Failed to cut audio, please refresh the browser and try again"
    );
  }

  if (videoCuttingStatus === "hasError") {
    toast.error(
      "Failed to cut video, please refresh the browser and try again"
    );
  }

  return null;
};
