import styled from "@emotion/styled";

export const StyledDownloadInfo = styled.div`
  display: flex;
  align-items: center;
  flex-direction: column;
  width: 60%
`;
