import React, { useEffect, useState } from "react";
import {
  useRecoilValue,
  useRecoilValueLoadable,
} from "recoil";
import { DownloadInfoModel } from "../../Models/DownloadInfo";
import { YoutubeType } from "../../Models/Youtube";
import { audioExtractorState } from "../../stores/audioExtractorState";
import { downloadLinkState } from "../../stores/downloadLinkState";

import { youtubeState } from "../../stores/YoutubeState";
import { youtubeTypeState } from "../../stores/YoutubeTypeState";
import { Nullable } from "../../types/global-types";
import { DomUtil } from "../../utils/DomUtil";
import { FileNameUtil } from "../../utils/FileNameUtil";
import { Button } from "../Button/Button";
import { ProgressBar } from "../ProgressBar/ProgressBar";
import { StyledDownloadInfo } from "./DownloadInfo.style";

export const DownloadInfo: React.FunctionComponent = ({}) => {
  const [downloadInfoModel, setDownloadInfoModel] =
    useState<Nullable<DownloadInfoModel>>(null);
  // const { pageName } = usePage();

  // const { state: cuttingStatus, contents: cuttingResult } =
  //   useRecoilValueLoadable(youtubeCutterState);
  const { state: fetchingYoutubeStatus, contents: fetchingYoutubeResult } =
    useRecoilValueLoadable(youtubeState);

  const {
    state: preparingDownloadLinkStatus,
    contents: preparingDownloadLinkResult,
  } = useRecoilValueLoadable(downloadLinkState(downloadInfoModel));

  const { state: extractingStatus, contents: extractingResult } =
    useRecoilValueLoadable(audioExtractorState("HomePage"));

  // const {
  //   state: processingYoutubeStatus,
  //   contents: processingYoutubeResult,
  // } = useRecoilValueLoadable(youtubeSplitterState);

  const youtubeType = useRecoilValue(youtubeTypeState);

  // const downloadVideoOrAudio = () => {
  //   if (!processingYoutubeResult) return;

  //   const fileName = FileNameUtil.getFileNameWithExtension({
  //     fileName: processingYoutubeResult.audioOnlyFile.name,
  //     youtubeType,
  //   });
  //   if (youtubeType === YoutubeType.Audio)
  //     DomUtil.downloadBlob({
  //       blob: processingYoutubeResult.audioOnlyFile,
  //       fileName,
  //     });
  //   else if (youtubeType === YoutubeType.Video)
  //     DomUtil.downloadBlob({
  //       blob: processingYoutubeResult.originalFile,
  //       fileName,
  //     });
  // };

  // const downloadCuttingResult = () => {
  //   const fileName = FileNameUtil.getFileNameWithExtension({
  //     fileName: cuttingResult.name,
  //     youtubeType,
  //   });

  //   DomUtil.downloadBlob({
  //     blob: cuttingResult,
  //     fileName,
  //   });
  // };
  const handleDownloadButtonClicked = () => {
    if (youtubeType === YoutubeType.Video) {
      return setDownloadInfoModel({
        downloadLink: fetchingYoutubeResult.downloadLink,
        title: FileNameUtil.getFileNameWithBranding(
          FileNameUtil.getFileNameWithExtension({
            fileName: fetchingYoutubeResult.title,
            youtubeType,
          })
        ),
      });
      // setDownloadLink({});
    }

    if (youtubeType === YoutubeType.Audio)
      setDownloadInfoModel({
        downloadLink: extractingResult.downloadLink,
        title: FileNameUtil.getFileNameWithBranding(
          FileNameUtil.getFileNameWithExtension({
            fileName: extractingResult.title,
            youtubeType,
          })
        ),
      });
  };

  const getStatusMessage = () => {
    if (fetchingYoutubeStatus === "loading") return "Getting download link";
    if (preparingDownloadLinkStatus === "loading")
      return "Preparing download link";
    if (extractingStatus === "loading") return "Extract audio from video";
    // if (processingYoutubeStatus === "loading")
    //   return "Processing youtube video";
    // if (cuttingStatus === "loading") return "Cutting";

    return "";
  };

  const loadingMessage = getStatusMessage();

  const downloadSuccess =
    fetchingYoutubeStatus !== "loading" &&
    fetchingYoutubeStatus !== "hasError" &&
    fetchingYoutubeResult?.id;

  const preparingDownloadLinkSuccess =
    preparingDownloadLinkStatus !== "loading" &&
    preparingDownloadLinkStatus !== "hasError" &&
    preparingDownloadLinkResult;

  // const processSuccess =
  //   processingYoutubeStatus !== "loading" &&
  //   processingYoutubeStatus !== "hasError" &&
  //   processingYoutubeResult;

  // const cutSuccess =
  //   cuttingStatus !== "loading" &&
  //   cuttingStatus !== "hasError" &&
  //   cuttingResult;

  useEffect(() => {
    if (preparingDownloadLinkSuccess) {
      DomUtil.downloadFIle(preparingDownloadLinkResult);
      setDownloadInfoModel(null);
    }
  }, [preparingDownloadLinkResult]);

  return (
    <StyledDownloadInfo>
      {loadingMessage && (
        <>
          <ProgressBar status={loadingMessage} />
          <div style={{ marginTop: 10 }}>
            Process time will depend on your video length ( appox. 2 minutes for
            an 1 hour video )
          </div>
        </>
      )}

      {!loadingMessage && downloadSuccess && (
        <Button onClick={handleDownloadButtonClicked}>Download Now</Button>
      )}
    </StyledDownloadInfo>
  );
};
