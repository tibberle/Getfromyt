import React, { useEffect, useState } from "react";
import { useRecoilValueLoadable, useRecoilValue } from "recoil";
import { DownloadInfoModel } from "../../Models/DownloadInfo";
import { YoutubeType } from "../../Models/Youtube";
import { audioCutterState, videoCutterState } from "../../stores/cutterState";
import { downloadLinkState } from "../../stores/downloadLinkState";
import { youtubeState } from "../../stores/YoutubeState";
import { youtubeTypeState } from "../../stores/YoutubeTypeState";
import { Nullable } from "../../types/global-types";
import { DomUtil } from "../../utils/DomUtil";
import { FileNameUtil } from "../../utils/FileNameUtil";
import { Button } from "../Button/Button";
import { ProgressBar } from "../ProgressBar/ProgressBar";
import { StyledDownloadInfo } from "./DownloadInfo.style";

export const DownloadInfoForCutter: React.FunctionComponent = ({}) => {
  const [downloadInfoModel, setDownloadInfoModel] =
    useState<Nullable<DownloadInfoModel>>(null);

  const { state: fetchingYoutubeStatus, contents: fetchingYoutubeResult } =
    useRecoilValueLoadable(youtubeState);

  const {
    state: preparingDownloadLinkStatus,
    contents: preparingDownloadLinkResult,
  } = useRecoilValueLoadable(downloadLinkState(downloadInfoModel));

  const { state: cutAudioStatus, contents: cutAudioResult } =
    useRecoilValueLoadable(audioCutterState);

  const { state: cutVideoStatus, contents: cutVideoResult } =
    useRecoilValueLoadable(videoCutterState);

  const youtubeType = useRecoilValue(youtubeTypeState);

  const handleDownloadButtonClicked = () => {
    if (youtubeType === YoutubeType.Video) {
      return setDownloadInfoModel({
        downloadLink: cutVideoResult.downloadLink,
        title: FileNameUtil.getFileNameWithBranding(
          FileNameUtil.getFileNameWithExtension({
            fileName: cutVideoResult.title,
            youtubeType,
          })
        ),
      });
    }
    if (youtubeType === YoutubeType.Audio)
      setDownloadInfoModel({
        downloadLink: cutAudioResult.downloadLink,
        title: FileNameUtil.getFileNameWithBranding(
          FileNameUtil.getFileNameWithExtension({
            fileName: cutAudioResult.title,
            youtubeType,
          })
        ),
      });
  };

  const getStatusMessage = () => {
    if (fetchingYoutubeStatus === "loading") return "Getting download link";
    if (preparingDownloadLinkStatus === "loading")
      return "Preparing download link";

    if (cutAudioStatus === "loading") return "Cutting Audio";
    if (cutVideoStatus === "loading") return "Cut Video";

    return "";
  };

  const loadingMessage = getStatusMessage();

  const downloadSuccess =
    fetchingYoutubeStatus !== "loading" &&
    fetchingYoutubeStatus !== "hasError" &&
    fetchingYoutubeResult?.id;

  const preparingDownloadLinkSuccess =
    preparingDownloadLinkStatus !== "loading" &&
    preparingDownloadLinkStatus !== "hasError" &&
    preparingDownloadLinkResult;

  const cuttingAudioSuccess =
    cutAudioStatus !== "loading" &&
    cutAudioStatus !== "hasError" &&
    cutAudioResult;

  const cuttingVideoSuccess =
    cutVideoStatus !== "loading" &&
    cutVideoStatus !== "hasError" &&
    cutVideoResult;

  useEffect(() => {
    if (preparingDownloadLinkSuccess) {
      DomUtil.downloadFIle(preparingDownloadLinkResult);
      setDownloadInfoModel(null);
    }
  }, [preparingDownloadLinkResult]);

  return (
    <StyledDownloadInfo>
      {loadingMessage && (
        <>
          <ProgressBar status={loadingMessage} />
          <div style={{ marginTop: 10 }}>
            Process time will depend on your video length ( appox. 2 minutes for
            an 1 hour video )
          </div>
        </>
      )}

      {!loadingMessage &&
        downloadSuccess &&
        (cuttingAudioSuccess || cuttingVideoSuccess) && (
          <Button onClick={handleDownloadButtonClicked}>Download Now</Button>
        )}
    </StyledDownloadInfo>
  );
};
