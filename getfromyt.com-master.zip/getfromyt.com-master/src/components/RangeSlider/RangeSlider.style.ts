import { theme } from "../../styles/theme";

const handle: React.CSSProperties = {
  height: "22px",
  width: "22px",
  marginTop: -6,
  backgroundColor: theme.backgroundColor.primary,
  borderColor: theme.successColor.primary,
  cursor: "pointer",
  outline: "none",
  
  
};

const track: React.CSSProperties = {

  border: "none",
  height: "8px",
  backgroundColor: theme.successColor.primary,

};

const rail: React.CSSProperties = {
  height: "8px",
  backgroundColor: theme.backgroundColor.secondary,
};

export const RangeSliderStyle = { handle, track, rail };
