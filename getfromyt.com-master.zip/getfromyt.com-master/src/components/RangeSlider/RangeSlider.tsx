/** @jsxImportSource @emotion/react */
import React from "react";
import { Range } from "rc-slider";
import { RangeSliderStyle } from "./RangeSlider.style";
import {
  DEFAULT_SPACING_REM,
  SMALL_SPACING_REM,
} from "../../styles/globalStyleConstants";
import { css } from "@emotion/react";
export interface RangeSliderProps {
  value?: [number, number];
  minValue?: number;
  maxValue?: number;
  step?: number;
  disabled?: boolean;
  onChange?: (v: number[]) => void;
}

export const RangeSlider: React.FunctionComponent<RangeSliderProps> = ({
  minValue = 0,
  maxValue = 100,
  value = [0, 100],
  onChange,
}) => {
  const { handle, track, rail } = RangeSliderStyle;
  return (
    <Range
      handleStyle={[handle, handle]}
      trackStyle={[track]}
      railStyle={rail}
      min={minValue}
      max={maxValue}
      value={value}
      onChange={onChange}
      css={css`
        margin-top: ${SMALL_SPACING_REM}rem;
        width: 98%;
        margin: ${SMALL_SPACING_REM}rem auto 0;
        @media (max-width: 650px) {
          width: 97%;
        }
        @media (max-width: 430px) {
          width: 95%;
        }
      `}
    />
  );
};
