/** @jsxImportSource @emotion/react */
import React from "react";
import { useRouter } from "next/router";
import {
  StyleActiveNavItem,
  StyleDisableNavItem,
  StyledNavItem,
} from "./NavItem.style";

interface Props {
  path: string;
  label: string;
  disabled?: boolean;
}

export const NavItem: React.FC<Props> = ({ path, label, disabled }) => {
  const router = useRouter();

  return (
    <StyledNavItem
      variant="ghost"
      color="black"
      css={[
        router.pathname === path && StyleActiveNavItem,
        disabled && StyleDisableNavItem,
      ]}
      href={path}
    >
      {label}
    </StyledNavItem>
  );
};
