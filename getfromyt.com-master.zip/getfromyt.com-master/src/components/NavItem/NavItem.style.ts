import { css } from "@emotion/react";
import styled from "@emotion/styled";
import { DEFAULT_SPACING_REM } from "../../styles/globalStyleConstants";
import { theme } from "../../styles/theme";
import { StyledButton } from "../Button/Button.style";

export const StyleActiveNavItem = css`
  background-color: ${theme.backgroundColor.tertiary};
  color: ${theme.textColor.primary};

  :hover {
    background-color: ${theme.backgroundColor.tertiary};
    color: ${theme.textColor.primary};
  }
  
`;

export const StyledNavItem = styled(StyledButton)`
  margin-right: ${DEFAULT_SPACING_REM}rem;

  :nth-last-of-type(1) {
    margin-right: 0;
  }
  @media (max-width: 860px) {
    margin-right: 0;
  }
`.withComponent("a");

export const StyleDisableNavItem = css`
  cursor: auto;
  color: ${theme.disabledColor.primary};
  background-color: "transparent";
  pointer-events: none;
  
`;
