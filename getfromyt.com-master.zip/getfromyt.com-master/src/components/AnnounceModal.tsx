import React from "react";
import { createPortal } from "react-dom";
import { useRecoilState } from "recoil";
import { announceModalOpenState } from "../stores/modalState";
import styled from "@emotion/styled";
import { Checkbox, Segment } from "semantic-ui-react";
import { Button } from "./Button/Button";
import { StyledTextFieldWrapper } from "../routes/ContactPage";
import { TextField } from "./TextField/TextField";
import { SurveySurvice } from "../services/SurveyService";
import { Loading } from "./Loading/Loading";
import { useRequest } from "../utils/useRequest";
import { BrowserUtils } from "../utils/BrowserUtils";

const ModalLayout = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.8);
  z-index: 20000;
  overflow-y: auto;
  overflow-x: hidden;
`;

const ModalContainer = styled.div`
  width: 50rem;
  @media (max-width: 900px) {
    width: 100%;
  }
  background: white;
  margin: auto;
  border-radius: 5px;
  position: absolute;
  left: 50%;
  margin-top: 12px;
  transform: translate(-50%, 0);
`;

const ModalHeader = styled.h2`
  text-align: center;
  padding-top: 1.875rem;
  padding-bottom: 1.25rem;
`;

const ModalContent = styled.div`
  padding-left: 1.25rem;
  padding-right: 1.25rem;
  li {
    margin-bottom: 1.25rem;
    img {
      @media (max-width: 515px) {
        width: 90%;
      }
    }
  }
`;

const CheckboxContainer = styled.div`
  padding-left: 1.5625rem;
  padding-bottom: 1.25rem;
`;

const SubmitButtonContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-around;
  padding-bottom: 1.25rem;
  margin: 0 auto;
  width: 30%;
  @media (max-width: 900px) {
    width: 15rem;
  }
`;

const OtherIdeaContainer = styled.div`
  padding-left: 1.5625rem;
`;

const LoadingContainer = styled.div`
  text-align: center;
`;

const options = [
  "Can select video quality when downloading",
  "Join multiple videos",
  "Join multiple audios with your images to create a music video",
  "Video to gif",
  "Can re-encode the video when cutting",
  "All In One tool where you can cut and join any videos and audios, or a part of this video with a part of other videos,....",
];

const LOCALSTORAGE_KEY_NAME = "Survey";

export const AnnounceModal = () => {
  const [modalOpen, setModalOpen] = useRecoilState(announceModalOpenState);
  const [optionsSelected, setOptionSelected] = React.useState<number[]>([]);
  const [otherIdeas, setOtherIdeas] = React.useState<string>("");
  const {
    makingRequest: submittingSurveyAnswers,
    makeRequest: submitSurveyAnswers,
  } = useRequest();

  React.useEffect(() => {
    if (
      !localStorage.getItem(LOCALSTORAGE_KEY_NAME) &&
      !BrowserUtils.isMobile()
    ) {
      setModalOpen(true);
    }

    return () => setModalOpen(false);
  }, []);

  const renderCheckboxOption = () => {
    return options.map((option, i) => (
      <Segment key={option}>
        <Checkbox
          onChange={(event, data) => {
            setOptionSelected((prevOptionsSelected) => {
              return data.checked
                ? [...prevOptionsSelected, i]
                : prevOptionsSelected.filter(
                    (opensSelected) => opensSelected !== i
                  );
            });
          }}
          label={option}
        />
      </Segment>
    ));
  };

  const sendSurveyResult = async () => {
    submitSurveyAnswers({
      request: () =>
        SurveySurvice.submitAnswer(
          optionsSelected.map((optionIndex) => options[optionIndex]),
          otherIdeas
        ),
      onSuccess: () => {
        setModalOpen(false);
        localStorage.setItem(LOCALSTORAGE_KEY_NAME, "done");
      },
      onError: () => {
        setModalOpen(false);
        localStorage.setItem(LOCALSTORAGE_KEY_NAME, "done");
      },
    });
  };
  const renderModalContent = () => {
    return (
      <ModalLayout>
        <ModalContainer>
          <ModalContent>
            <ModalHeader>
              We just released a new version of getfromyt
            </ModalHeader>
            <ol>
              <li>
                Now you can directly go to getfromyt with the link pre-entered
                by:
                <img src="/tip.png" alt="tip from getfromyt.com"></img>
              </li>
              <li>
                Improved time precision when cutting - the resulting videos
                might be a bit longer as we cannot cut in the middle of the
                frame.
              </li>
              <li>
                Open contact form so that you can contact us regarding anything
              </li>
              <li>
                You will notice the process time will take a bit longer but the
                download time is almost INSTANT.
              </li>
              <li>
                Because of Covid, we have some free time to add functionalities
                to this page, let's us know what you most interested in
              </li>
            </ol>
            {submittingSurveyAnswers ? (
              <LoadingContainer>
                <Loading />
              </LoadingContainer>
            ) : (
              <>
                <CheckboxContainer>{renderCheckboxOption()}</CheckboxContainer>
                <OtherIdeaContainer>
                  <StyledTextFieldWrapper fullWidth={true}>
                    <TextField
                      label="Any Other Ideas ? "
                      placeholder="Let's us know your awesome ideas here "
                      onChange={setOtherIdeas}
                    />
                  </StyledTextFieldWrapper>
                </OtherIdeaContainer>
                <SubmitButtonContainer>
                  <Button
                    onClick={sendSurveyResult}
                    disabled={!otherIdeas && optionsSelected.length === 0}
                  >
                    Submit
                  </Button>
                  <Button color="error" onClick={() => setModalOpen(false)}>
                    Close
                  </Button>
                </SubmitButtonContainer>
              </>
            )}
          </ModalContent>
        </ModalContainer>
      </ModalLayout>
    );
  };

  console.log("optionsSelected", optionsSelected);
  return modalOpen
    ? createPortal(
        renderModalContent(),
        document.querySelector("#annouceModal")!
      )
    : null;
};
