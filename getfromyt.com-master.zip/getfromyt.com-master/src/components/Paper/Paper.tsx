import React from "react";
import { StyledPaper, StyledPaperProps } from "./Paper.style";

export interface PaperProps {}

export const Paper: React.FunctionComponent<PaperProps & StyledPaperProps> = (
  props
) => {
  const { children, center, outline } = props;
  return (
    <StyledPaper {...props} center={center} outline={outline}>
      {children}
    </StyledPaper>
  );
};
