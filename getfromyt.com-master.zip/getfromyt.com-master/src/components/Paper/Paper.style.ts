import styled from "@emotion/styled";
import { DEFAULT_BORDER_RADIUS } from "../../styles/globalStyleConstants";

export interface StyledPaperProps {
  center?: boolean;
  outline?: boolean;
}

export const StyledPaper = styled.section<StyledPaperProps>`
  width: 100%;
  min-height: 20px;
  border-radius: ${DEFAULT_BORDER_RADIUS}px;
  display: flex;
  flex-direction: column;
  background-color: ${({ theme }) => theme.backgroundColor.primary};
  max-width: 1024px;
  margin: 0 auto;
  align-items: ${({ center }) => (center ? "center" : "initial")};
  margin-bottom: 20px;
  ${({ outline, theme }) =>
    outline && `border: 1px solid ${theme.backgroundColor.tertiary}`}
`;
