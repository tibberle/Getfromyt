import React from "react";
import { StyledNavbar } from "../HeaderNavbar/HeaderNavbar.style";
import { NavItem } from "../NavItem/NavItem";
import { Typography } from "../Typography/Typography";
import { StyledFooter, StyledFooterWrapper } from "./Footer.style";

export interface FooterProps {}

export const Footer: React.FunctionComponent<FooterProps> = () => {
  return (
    <StyledFooter>
      <StyledFooterWrapper>
        <Typography color="inherit" tag="p" variant="copyright">
          © 2020 Getfromyt. All rights reserved.
        </Typography>
        <StyledNavbar>
          <NavItem path="/about" label="About Us" />
          <NavItem path="/contact" label="Contact" />
          <NavItem path="/faq" label="FAQ" />
          <NavItem path="/terms-of-service" label="Terms of Service" />
          <NavItem path="/privacy-policy" label="Privacy Policy" />
        </StyledNavbar>
      </StyledFooterWrapper>
    </StyledFooter>
  );
};
