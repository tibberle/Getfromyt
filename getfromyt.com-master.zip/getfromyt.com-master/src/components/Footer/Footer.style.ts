import styled from "@emotion/styled";
import { ContainerMaxWidth } from "../../styles/common/Container";
import {
  EXTRA_LARGE_SPACING_REM,
  SMALL_SPACING_REM,
} from "../../styles/globalStyleConstants";

export const StyledFooter = styled.footer`
  margin-left: auto;
  margin-right: auto;
  margin-top: -16px;
  height: 87px;
  padding: ${SMALL_SPACING_REM}rem 0;
  display: flex;
  align-items: center;
  color: ${({ theme }) => theme.textColor.tertiary};
  background-color: ${({ theme }) => theme.backgroundColor.primary};
  @media (max-width: 910px) {
    height: 100px;
  }
`;

export const StyledFooterWrapper = styled.div`
  ${ContainerMaxWidth};
  width: 1024px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: auto;
  padding: 0 ${EXTRA_LARGE_SPACING_REM}rem;
  @media (max-width: 910px) {
    flex-direction: column;
    padding: 0;
  }
`;
