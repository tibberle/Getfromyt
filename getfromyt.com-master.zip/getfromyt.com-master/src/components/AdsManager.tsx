import React from "react";

const putAdsScripts = () => {
  const socialBarScript = document.createElement("script");
  socialBarScript.src =
    "https://sodallay.com/af/15/00/af1500c93f56b6e9b6e6aa9c203b98ed.js";
  socialBarScript.async = true;
  const popUnderScript = document.createElement("script");

  popUnderScript.onerror = (window as any).absda;
  popUnderScript.src =
    "https://sodallay.com/65/53/13/6553131c691439f11f09d0d1292b2606.js";
  document.body.appendChild(popUnderScript);
  document.body.appendChild(socialBarScript);

  const videoAdScript = document.createElement("script");
  videoAdScript.async = true;
  videoAdScript.src = "https://serving.stat-rock.com/player.js";

  const inplaceAdContainer = document.getElementById("in-place-ad-container");
  const contentVideoAdScript = document.createElement("script");
  contentVideoAdScript.id = "content-video-ad-script"
  contentVideoAdScript.textContent = `(function(){var s=document.querySelector('#content-video-ad-script');s.removeAttribute("data-playerPro");(playerPro=window.playerPro||[]).push({id:"lj_Wil3il6rr",after:s});})();`;

  document.head.appendChild(videoAdScript);
  inplaceAdContainer?.append(contentVideoAdScript);
};

export const AdsManager = () => {
  React.useEffect(() => {
    putAdsScripts();
  }, []);
  return null;
};
