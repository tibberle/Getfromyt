import styled from "@emotion/styled";
import { DEFAULT_SPACING_REM, EXTRA_LARGE_SPACING_REM, EXTRA_SMALL_SPACING_REM, LARGE_SPACING_REM, SMALL_SPACING_REM } from "../../styles/globalStyleConstants";

export const StyledLogoContainer = styled.div`
  display: flex;
`;

export const StyledLogo = styled.img`
  width: 100%;
  background-size: 100%;
  @media (max-width: 860px) {
    margin-bottom:${DEFAULT_SPACING_REM}rem;
  }
  @media (max-width: 570px) {
    width: 90%;
    margin: 0 auto ${DEFAULT_SPACING_REM}rem;;
  }
  @media (max-width: 500px) {
    width: 70%;
    margin: 0 auto ${DEFAULT_SPACING_REM}rem;;
  }
  @media (max-width: 430px) {
    width: 60%;
    margin: 0 auto ${DEFAULT_SPACING_REM}rem;;
  }
`;
