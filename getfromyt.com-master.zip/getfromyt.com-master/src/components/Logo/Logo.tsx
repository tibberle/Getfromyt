import React from "react";
import { StyledLogoContainer, StyledLogo } from "./Logo.style";

export interface LogoProps {}

export const Logo: React.FunctionComponent<LogoProps> = () => {
  return (
    <StyledLogoContainer>
      <StyledLogo src="/logo.png" alt="Logo of Getfromyt" />
    </StyledLogoContainer>
  );
};
