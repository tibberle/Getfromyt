import { atom, DefaultValue, selector } from "recoil";
import {
  getNumberOfUsageForToday,
  setNumberOfUsageForToday,
} from "../services/usageService";

export const NUMBER_OF_FREE_DOWNLOAD = 2;

export const usageCounterState = atom<number>({
  key: "usage",
  default: 0,
  effects_UNSTABLE: [
    ({ onSet, setSelf, trigger }) => {
      setSelf(getNumberOfUsageForToday());

      onSet((usageCounter, prevUsageCounter) => {
        if (prevUsageCounter instanceof DefaultValue && trigger === "get")
          return;

        if (usageCounter instanceof DefaultValue) return;

        setNumberOfUsageForToday(usageCounter);
      });
    },
  ],
});

export const adBlockDetectedState = atom<boolean>({
  key: "adBlockDetected",
  default: false,
});

export const blockUsageState = selector<boolean>({
  key: "blockUsage",
  get: ({ get }) => {
    const currentNumberOfUsage = get(usageCounterState);
    const adBlockDetected = get(adBlockDetectedState);

    return currentNumberOfUsage >= NUMBER_OF_FREE_DOWNLOAD && adBlockDetected;
  },
});
