import { atom } from "recoil";
import { Nullable } from "../types/global-types";

export const youtubeIdState = atom<Nullable<string>>({
  key: "youtubeId",
  default: null,
});
