import { atom, selector, selectorFamily } from "recoil";
import { YoutubeType } from "../Models/Youtube";
import { FFmpegService } from "../services/FFmpegService";
import { Nullable } from "../types/global-types";
import { DomUtil } from "../utils/DomUtil";
import { FileNameUtil } from "../utils/FileNameUtil";
import {
  convertSecondsToHHMMSSXX,
  formatMillisecondToHHMMSSXX,
  millisecondToHHMMSSXX,
} from "../utils/timeUtils";
import { youtubeState } from "./YoutubeState";
import { youtubeTypeState } from "./YoutubeTypeState";

export const cutTimeState = atom<
  Nullable<{ startTime: number; endTime: number }>
>({
  key: "cutTime",
  default: null,
});

export const youtubeCutterState = selector<Nullable<File>>({
  key: "youtubeCutter",
  get: async ({ get }) => {
    const youtube = get(youtubeState);
    const type = get(youtubeTypeState);
    const cutTime = get(cutTimeState);

    if (!youtube || !cutTime) return null;

    const { startTime, endTime } = cutTime;

    const start = formatMillisecondToHHMMSSXX(
      millisecondToHHMMSSXX(startTime * 1000)
    );

    const end = formatMillisecondToHHMMSSXX(
      millisecondToHHMMSSXX(endTime * 1000)
    );

    const { id, title } = youtube;
    const outputFileName = FileNameUtil.combineFileNameWithTime({
      fileName: id,
      start,
      end,
    });

    if (type === YoutubeType.Audio) {
      const outputFileNameWithExtensions =
        FileNameUtil.getFileNameWithExtension({
          fileName: outputFileName,
          youtubeType: type,
          custom: "m4a",
        });
      const audioFileCutSuccess = await FFmpegService.cutAudio({
        fileName: FileNameUtil.getAudioOnlyFileName(id, "m4a"),
        start,
        end,
        outputFileName: outputFileNameWithExtensions,
      });

      if (!audioFileCutSuccess) return null;

      const cutAudioFile = FFmpegService.readFile(outputFileNameWithExtensions);

      return new File(
        [cutAudioFile!.buffer],
        FileNameUtil.getFileNameWithBranding(title)
      );
    }

    const videoOnlyFileName = FileNameUtil.getVideoOnlyFileName(id);
    const audioOnlyFileName = FileNameUtil.getAudioOnlyFileName(id, "m4a");

    const outputFileNameWithExtension = FileNameUtil.getFileNameWithExtension({
      fileName: outputFileName,
      youtubeType: YoutubeType.Video,
    });

    const cutVideoOnlySuccess = await FFmpegService.cutFile({
      fileName: videoOnlyFileName,
      start,
      end,
      outputFileName: FileNameUtil.getVideoOnlyFileName(outputFileName),
    });

    if (!cutVideoOnlySuccess) return null;

    const cutVideoOnlyFile = FFmpegService.readFile(
      FileNameUtil.getVideoOnlyFileName(outputFileName)
    );

    const duration = await DomUtil.getBlobDuration(
      new Blob([cutVideoOnlyFile!.buffer])
    );

    const audioFileCutSuccess = await FFmpegService.cutFile({
      fileName: audioOnlyFileName,
      start,
      end,
      duration: convertSecondsToHHMMSSXX(duration),
      outputFileName: FileNameUtil.getAudioOnlyFileName(outputFileName, "m4a"),
    });

    if (!audioFileCutSuccess) return null;

    const joinAudioAndVideoSuccess = await FFmpegService.joinVideoAndAudio({
      videoFileName: FileNameUtil.getVideoOnlyFileName(outputFileName),
      audioFileName: FileNameUtil.getAudioOnlyFileName(outputFileName, "m4a"),
      outputFileName: outputFileNameWithExtension,
    });

    if (!joinAudioAndVideoSuccess) return null;

    const result = FFmpegService.readFile(outputFileNameWithExtension);

    return new File(
      [result!.buffer],
      FileNameUtil.getFileNameWithBranding(title)
    );
  },
});
