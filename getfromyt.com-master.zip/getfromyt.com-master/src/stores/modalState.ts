import { atom } from "recoil";

export const announceModalOpenState = atom({
    key: "accounceModalOpen",
    default: false
})