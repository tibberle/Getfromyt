import { atom } from "recoil";
import { YoutubeType } from "../Models/Youtube";
import { Nullable } from "../types/global-types";

export const youtubeTypeState = atom<Nullable<YoutubeType>>({
  key: "youtubeType",
  default: null,
});
