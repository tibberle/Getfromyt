import { atom, selector, selectorFamily } from "recoil";
import { DownloadInfoModel } from "../Models/DownloadInfo";
import { YoutubeType } from "../Models/Youtube";
import { VideoProcessorService } from "../services/VideoProcessorService";
import { Nullable } from "../types/global-types";
import { TimerUtils } from "../utils/TimerUtils";
import { youtubeState } from "./YoutubeState";
import { youtubeTypeState } from "./YoutubeTypeState";

export const cuttingDetailState = atom<
  Nullable<{
    startInMilliSeconds: number;
    endInMilliSeconds: number;
  }>
>({
  key: "cutTime",
  default: null,
});

export const audioCutterState = selector<Nullable<DownloadInfoModel>>({
  key: "audioCutter",
  get: async ({ get }) => {
    const cuttingDetail = get(cuttingDetailState);
    if (!cuttingDetail) return null;

    const youtubeType = get(youtubeTypeState);
    if (!youtubeType || youtubeType !== YoutubeType.Audio) return null;

    const youtube = get(youtubeState);
    if (!youtube) return null;

    const downloadInfo = await VideoProcessorService.cutAudio({
      ...cuttingDetail,
      id: youtube.id,
    });

    await TimerUtils.sleepXSeconds(20);

    return {
      downloadLink: downloadInfo.downloadLink,
      title: youtube.title,
    };
  },
});

export const videoCutterState = selector<Nullable<DownloadInfoModel>>({
  key: "videoCutter",
  get: async ({ get }) => {
    const cuttingDetail = get(cuttingDetailState);
    if (!cuttingDetail) return null;

    const youtubeType = get(youtubeTypeState);

    if (!youtubeType || youtubeType === YoutubeType.Audio) return null;

    const youtube = get(youtubeState);

    if (!youtube) return null;

    const downloadInfo = await VideoProcessorService.cutVideo({
      ...cuttingDetail,
      id: youtube.id,
    });

    await TimerUtils.sleepXSeconds(20);

    return {
      downloadLink: downloadInfo.downloadLink,
      title: youtube.title,
    };
  },
});
