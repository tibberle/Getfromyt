import { selector, selectorFamily } from "recoil";
import { DownloadInfoModel } from "../Models/DownloadInfo";
import { YoutubeType } from "../Models/Youtube";
import { VideoProcessorService } from "../services/VideoProcessorService";
import { Nullable } from "../types/global-types";
import { youtubeState } from "./YoutubeState";
import { youtubeTypeState } from "./YoutubeTypeState";

export const audioExtractorState = selectorFamily<
  Nullable<DownloadInfoModel>,
  "HomePage" | "CutterPage"
>({
  key: "audioExtractor",
  get:
    (page) =>
    async ({ get }) => {
      if (page === "CutterPage") return null;
      
      const youtubeType = get(youtubeTypeState);

      if (!youtubeType || youtubeType !== YoutubeType.Audio) return null;

      const youtube = get(youtubeState);

      if (!youtube) return null;

      const downloadInfo = await VideoProcessorService.extractAudio(youtube.id);
      return {
        downloadLink: downloadInfo.downloadLink,
        title: youtube.title,
      };
    },
});
