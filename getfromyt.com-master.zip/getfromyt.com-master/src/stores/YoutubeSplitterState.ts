import { selector } from "recoil";
import { FFmpegService } from "../services/FFmpegService";
import { FileNameUtil } from "../utils/FileNameUtil";
import { youtubeState } from "./YoutubeState";

export const youtubeSplitterState = selector({
  key: "YoutubeSplitter",
  get: async ({ get }) => {
    return null;
    // const youtube = get(youtubeState);

    // if (youtube === null) return null;

    // const { id, downloadLink, title } = youtube;

    // await FFmpegService.writeFileByUrl({
    //   fileName: id,
    //   url: downloadLink,
    // });

    // const splittingSuccess = await FFmpegService.splitVideoAndAudio(youtube.id);

    // if (!splittingSuccess)
    //   throw "Cannot process this video, please refresh your browser and try again";

    // const originalFile = FFmpegService.readFile(id);
    // const videoOnlyFile = FFmpegService.readFile(
    //   FileNameUtil.getVideoOnlyFileName(id)
    // );
    // const audioOnlyFile = FFmpegService.readFile(
    //   FileNameUtil.getAudioOnlyFileName(id, "m4a")
    // );

    // return {
    //   audioOnlyFile: new File(
    //     [audioOnlyFile!.buffer],
    //     FileNameUtil.getFileNameWithBranding(title)
    //   ),
    //   videoOnlyFile: new File(
    //     [videoOnlyFile!.buffer],
    //     FileNameUtil.getFileNameWithBranding(title)
    //   ),
    //   originalFile: new File(
    //     [originalFile!.buffer],
    //     FileNameUtil.getFileNameWithBranding(title)
    //   ),
    // };
  },
});
