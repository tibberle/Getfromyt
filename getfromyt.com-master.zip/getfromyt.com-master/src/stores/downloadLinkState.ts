import { selectorFamily } from "recoil";
import { RequestService } from "../services/requestServices";
import { Nullable } from "../types/global-types";
import { TimerUtils } from "../utils/TimerUtils";

export const downloadLinkState = selectorFamily<
  Nullable<File>,
  Nullable<{ downloadLink: string; title: string }>
>({
  key: "downloadLink",
  get: (downloadInfo) => async () => {
    if (!downloadInfo) return null;

    const { downloadLink, title } = downloadInfo;

    const file = await RequestService.downloadFile({
      url: downloadLink,
      title,
    });

    await TimerUtils.sleepXSeconds(10);
    
    return file;
  },
});
