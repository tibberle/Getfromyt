import { selector } from "recoil";
import { Youtube } from "../Models/Youtube";
import { YoutubeService } from "../services/YoutubeService";
import { Nullable } from "../types/global-types";
import { TimerUtils } from "../utils/TimerUtils";
import { youtubeIdState } from "./youtubeIdState";

export const youtubeState = selector<Nullable<Youtube>>({
  key: "Youtube",
  get: async ({ get }) => {
    const youtubeId = get(youtubeIdState);
    if (!youtubeId) return null;

    await TimerUtils.sleepXSeconds(10);

    const youtube = await YoutubeService.downloadYoutubeById(youtubeId);

    return youtube;
  },
});
