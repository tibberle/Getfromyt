import { NextPage } from "next";
import { NextSeo } from "next-seo";
import React from "react";
import { HomePage } from "../routes/HomePage";

const IndexPage: NextPage = () => {
  return (
    <>
      <NextSeo
        title="YouTube Converter: Download Mp3 & Mp4 Online | Getfromyt"
        description="Getfromyt is a Converter which will help you download videos Online from YouTube to Mp3 or Mp4 based on your choices."
        canonical="https://getfromyt.com/"
        openGraph={{
          type: "website",
          url: "https://getfromyt.com/",
          title: "YouTube Converter: Download Mp3 & Mp4 Online | Getfromyt",
          description:
            "Getfromyt is a Converter which will help you download videos Online from YouTube to Mp3 or Mp4 based on your choices.",
          images: [
            {
              url: "https://getfromyt.com/favicon.png",
              width: 500,
              height: 500,
              alt: "Getfromyt_logo",
            },
          ],
          site_name: "Getfromyt",
        }}
        twitter={{
          handle: "@Getfromyt",
          site: "@Getfromyt",
          cardType: "summary_large_image",
        }}
        facebook={{
          appId: "2646194088934256",
        }}
      />
      <HomePage />
    </>
  );
};

export default IndexPage;
