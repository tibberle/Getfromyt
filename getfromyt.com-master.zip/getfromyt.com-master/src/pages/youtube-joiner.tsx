import React from "react";
import { NextPage } from "next";
import { JoinerRoute } from "../routes/JoinerPage";
import { DescriptionSection } from "../components/DescriptionSection/DescriptionSection";
import { joinerPageData } from "../static/joinerPageData";
import { NextSeo } from "next-seo";

const JoinerPage: NextPage = () => {
  return (
    <>
      <NextSeo
        title="YouTube Merger: Combine Videos & Songs Online | Getfromyt"
        description="Getfromyt is a Merger which will allow you to merge YouTube Videos (Audios) and download them into a file at the same. We will show you: How to do that?"
        canonical="https://getfromyt.com/youtube-joiner"
        openGraph={{
          type: "website",
          url: "https://getfromyt.com/youtube-joiner",
          title: "YouTube Merger: Combine Videos & Songs Online | Getfromyt",
          description:
            "Getfromyt is a Merger which will allow you to merge YouTube Videos (Audios) and download them into a file at the same. We will show you: How to do that?",
          images: [
            {
              url: "https://getfromyt.com/favicon.png",
              width: 500,
              height: 500,
              alt: "Getfromyt_logo",
            },
          ],
          site_name: "Getfromyt",
        }}
        twitter={{
          handle: "@Getfromyt",
          site: "@Getfromyt",
          cardType: "summary_large_image",
        }}
        facebook={{
          appId: "2646194088934256",
        }}
      />
      <JoinerRoute />
      <DescriptionSection contents={joinerPageData} />
    </>
  );
};

export default JoinerPage;
