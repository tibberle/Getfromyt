import { NextApiRequest, NextApiResponse } from "next";
import nc from "next-connect";
import { connectToDB } from "../../server/infra/connectToDB";

const handler = nc<NextApiRequest, NextApiResponse>({});

handler.post(async (req, res) => {
  const { db } = await connectToDB();

  const ip = req.headers["x-real-ip"] || req.connection.remoteAddress;
  try {
    await db.collection("survey").insertOne({
      ip,
      answers: req.body.answers,
      otherIdeas: req.body.otherIdeas,
    });
  } catch (error) {
    console.log("error", error);
    return res.status(500).send({});
  }
  return res.status(200).send({});
});

export default handler;
