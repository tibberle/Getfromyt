import { NextApiRequest, NextApiResponse } from "next";
import nc from "next-connect";
import { createTransport } from "nodemailer";

const handler = nc<NextApiRequest, NextApiResponse>({});

const transporter = createTransport({
  host: "smtp.zoho.com.au",
  port: 465,
  secure: true,
  auth: {
    user: process.env.EMAIL_SERVER_USER,
    pass: process.env.EMAIL_SERVER_PASSWORD,
  },
});

handler.post(async (req, res) => {
  console.log("process.env.EMAIL_SERVER_USE", process.env.EMAIL_SERVER_USE);
  try {
    await transporter.sendMail({
      from: '"Rossi Service 👻" <service@rossitrile.com>',
      to: "ross@rossitrile.com",
      subject: "Getfromyt Contact Form", // Subject line
      html: `<h1>${req.body.name}</h1>
            <h2>${req.body.email}</h2>
            <h3>${req.body.message}</h3>
      `,
    });
  } catch (error) {
    console.log("error", error);
    return res.status(500).send({});
  }

  return res.status(200).send({});
});

export default handler;
