import React from "react";
import { NextPage } from "next";
import { DescriptionSection } from "../components/DescriptionSection/DescriptionSection";
import { PrivacyPolicyData } from "../static/privacyPolicyData";
import { NextSeo } from "next-seo";

const PrivacyPolicyPage: NextPage = () => {
  return (
    <>
      <NextSeo
        title="Privacy Policy | Getfromyt"
        description="Conditions to use Getfromyt. You should follow to not be banned!!"
        canonical="https://getfromyt.com/privacy-policy"
        openGraph={{
          type: "website",
          url: "https://getfromyt.com/privacy-policy",
          title: "Privacy Policy | Getfromyt",
          description:
            "Conditions to use Getfromyt. You should follow to not be banned!!",
          images: [
            {
              url: "https://getfromyt.com/favicon.png",
              width: 500,
              height: 500,
              alt: "Getfromyt_logo",
            },
          ],
          site_name: "Getfromyt",
        }}
        twitter={{
          handle: "@Getfromyt",
          site: "@Getfromyt",
          cardType: "summary_large_image",
        }}
        facebook={{
          appId: "2646194088934256",
        }}
      />
      <DescriptionSection
        title={<>Privacy Policy</>}
        contents={PrivacyPolicyData}
      />
    </>
  );
};

export default PrivacyPolicyPage;
