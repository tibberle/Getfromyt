import React from "react";
import { NextPage } from "next";
import { TOSPageData } from "../static/tosPageData";
import { DescriptionSection } from "../components/DescriptionSection/DescriptionSection";
import { NextSeo } from "next-seo";

const TOSPage: NextPage = () => {
  return (
    <>
      <NextSeo
        title="Terms Of Service | Getfromyt"
        description="The words of which the initial letter is capitalized have meanings defined under the following conditions. These Terms and Conditions: Device, Service,..."
        canonical="https://getfromyt.com/terms-of-service"
        openGraph={{
          type: "website",
          url: "https://getfromyt.com/terms-of-service",
          title: "Terms Of Service | Getfromyt",
          description:
            "The words of which the initial letter is capitalized have meanings defined under the following conditions. These Terms and Conditions: Device, Service,...",
          images: [
            {
              url: "https://getfromyt.com/favicon.png",
              width: 500,
              height: 500,
              alt: "Getfromyt_logo",
            },
          ],
          site_name: "Getfromyt",
        }}
        twitter={{
          handle: "@Getfromyt",
          site: "@Getfromyt",
          cardType: "summary_large_image",
        }}
        facebook={{
          appId: "2646194088934256",
        }}
      />
      <DescriptionSection
        title={<>Terms Of Service</>}
        contents={TOSPageData as any}
      />
    </>
  );
};

export default TOSPage;
