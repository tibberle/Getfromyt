import React from "react";
import { NextPage } from "next";
import { ContactRoute } from "../routes/ContactPage";
import { NextSeo } from "next-seo";

const ContactPage: NextPage = () => {
  return (
    <>
      <NextSeo
        title="Contact | Getfromyt"
        description="Maybe you want us to improve the feature on this app? Feel free to send us a message. Please note: we will only answer contact requests written in English."
        canonical="https://getfromyt.com/contact"
        openGraph={{
          type: "website",
          url: "https://getfromyt.com/contact",
          title: "Contact | Getfromyt",
          description:
            "Maybe you want us to improve the feature on this app? Feel free to send us a message. Please note: we will only answer contact requests written in English.",
          images: [
            {
              url: "https://getfromyt.com/favicon.png",
              width: 500,
              height: 500,
              alt: "Getfromyt_logo",
            },
          ],
          site_name: "Getfromyt",
        }}
        twitter={{
          handle: "@Getfromyt",
          site: "@Getfromyt",
          cardType: "summary_large_image",
        }}
        facebook={{
          appId: "2646194088934256",
        }}
      />
      <ContactRoute />
    </>
  );
};

export default ContactPage;
