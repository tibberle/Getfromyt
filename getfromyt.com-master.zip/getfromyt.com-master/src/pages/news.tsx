import React from "react";
import { NextPage } from "next";
import { NewsRoute } from "../routes/NewsPage";
import { NextSeo } from "next-seo";

const NewsPage: NextPage = () => {
  return (
    <>
      <NextSeo
        title="News | Getfromyt"
        description="Update!! All changes from our service will be prominently posted here."
        canonical="https://getfromyt.com/news"
        openGraph={{
          type: "website",
          url: "https://getfromyt.com/news",
          title: "News | Getfromyt",
          description:
            "Update!! All changes from our service will be prominently posted here.",
          images: [
            {
              url: "https://getfromyt.com/favicon.png",
              width: 500,
              height: 500,
              alt: "Getfromyt_logo",
            },
          ],
          site_name: "Getfromyt",
        }}
        twitter={{
          handle: "@Getfromyt",
          site: "@Getfromyt",
          cardType: "summary_large_image",
        }}
        facebook={{
          appId: "2646194088934256",
        }}
      />
      <NewsRoute />
    </>
  );
};

export default NewsPage;
