import Document, {
  Main,
  NextScript,
  Html,
  DocumentContext,
} from "next/document";
import React from "react";
import { Header } from "../Html/Header";

export default class MyDocument extends Document {
  render() {
    return (
      <Html lang="en">
        <Header />
        <body>
          <Main />
          <NextScript />
          <div id="annouceModal"></div>
        </body>
      </Html>
    );
  }
}

MyDocument.getInitialProps = async (ctx: DocumentContext) => {
  const initialProps = await Document.getInitialProps(ctx);

  return initialProps;
};
