import { NextPage } from "next";
import { NextSeo } from "next-seo";
import React from "react";
import { Custom404Route } from "../routes/404Page";

const Custom404Page: NextPage = () => {
  return (
    <>
      <NextSeo
        title="404 - Page Not Found | Getfromyt"
        description="Oops, wrong page!"
        canonical="https://getfromyt.com/404"
        openGraph={{
          type: "website",
          url: "https://getfromyt.com/404",
          title: "404 - Page Not Found | Getfromyt",
          description: "Oops, wrong page!",
          images: [
            {
              url: "https://getfromyt.com/favicon.png",
              width: 500,
              height: 500,
              alt: "Getfromyt_logo",
            },
          ],
          site_name: "Getfromyt",
        }}
        twitter={{
          handle: "@Getfromyt",
          site: "@Getfromyt",
          cardType: "summary_large_image",
        }}
        facebook={{
          appId: "2646194088934256",
        }}
      />
      <Custom404Route />
    </>
  );
};

export default Custom404Page;
