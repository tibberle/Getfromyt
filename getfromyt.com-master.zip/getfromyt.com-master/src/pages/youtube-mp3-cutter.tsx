import redirect from "nextjs-redirect";
export default redirect("https://getfromyt.com/youtube-cutter", {
  statusCode: 301,
});
