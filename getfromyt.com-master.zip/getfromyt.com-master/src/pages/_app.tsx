import React from "react";
import { Global, ThemeProvider } from "@emotion/react";
import { globalStyle } from "../styles/globalStyle";
import { theme } from "../styles/theme";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "rc-slider/assets/index.css";
import "semantic-ui-css/semantic.min.css";
import { Layout } from "../components/Layout/Layout";
import { FFmpegService } from "../services/FFmpegService";
import { RecoilRoot, useSetRecoilState } from "recoil";
import { useDetectAdBlock } from "../utils/useDetectAdBlock";
import { adBlockDetectedState } from "../stores/usageState";
import { NotificationManager } from "../components/NotificationManager";
import { Loading } from "../components/Loading/Loading";
import { AdsManager } from "../components/AdsManager";

const MyApp = ({ Component, pageProps }: any) => {
  const [finishInitializeApp, setFinishInitializeApp] = React.useState(false);
  const { adBlockDetected } = useDetectAdBlock();
  const setAdBlockDetected = useSetRecoilState(adBlockDetectedState);

  React.useEffect(() => {
    setFinishInitializeApp(true);
  }, []);

  React.useEffect(() => {
    setAdBlockDetected(adBlockDetected);
  }, [adBlockDetected]);

  return (
    <>
      <ThemeProvider theme={theme}>
        {finishInitializeApp ? (
          <>
            <Global styles={globalStyle} />
            <Layout>
              <Component {...pageProps} />
            </Layout>
            <ToastContainer
              closeOnClick
              pauseOnFocusLoss
              pauseOnHover
              position="bottom-left"
            />
            <NotificationManager />
            <AdsManager />
            {/* <AnnounceModal /> */}
          </>
        ) : (
          <Loading center />
        )}
      </ThemeProvider>
    </>
  );
};

const MyAppWithRecoilProvider = (props: any) => {
  return (
    <RecoilRoot>
      <MyApp {...props} />
    </RecoilRoot>
  );
};

export default MyAppWithRecoilProvider;
