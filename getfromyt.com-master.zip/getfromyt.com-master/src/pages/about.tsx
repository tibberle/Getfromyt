import React from "react";
import { NextPage } from "next";
import { DescriptionSection } from "../components/DescriptionSection/DescriptionSection";
import { AboutPageData } from "../static/aboutPageData";
import { NextSeo } from "next-seo";

const AboutPage: NextPage = () => {
  return (
    <>
      <NextSeo
        title="About Us | Getfromyt"
        description="Something about this converter: Getfromyt"
        canonical="https://getfromyt.com/about"
        openGraph={{
          type: "website",
          url: "https://getfromyt.com/about",
          title: "About Us | Getfromyt",
          description: "Something about this converter: Getfromyt",
          images: [
            {
              url: "https://getfromyt.com/favicon.png",
              width: 500,
              height: 500,
              alt: "Getfromyt_logo",
            },
          ],
          site_name: "Getfromyt",
        }}
        twitter={{
          handle: "@Getfromyt",
          site: "@Getfromyt",
          cardType: "summary_large_image",
        }}
        facebook={{
          appId: "2646194088934256",
        }}
      />
      <DescriptionSection title={<>About Us</>} contents={AboutPageData} />
    </>
  );
};

export default AboutPage;
