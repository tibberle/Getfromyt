import React from "react";
import { NextPage } from "next";
import { DescriptionSection } from "../components/DescriptionSection/DescriptionSection";
import { FAQPageData } from "../static/faqPageData";
import { NextSeo } from "next-seo";

const FAQPage: NextPage = () => {
  return (
    <>
      <NextSeo
        title="FAQ | Getfromyt"
        description="I stuck. what's wrong? | How to get a MP3 from YouTube? | What is the longest duration of a Mp3 file is converted?"
        canonical="https://getfromyt.com/faq"
        openGraph={{
          type: "website",
          url: "https://getfromyt.com/faq",
          title: "FAQ | Getfromyt",
          description:
            "I stuck. what's wrong? | How to get a MP3 from YouTube? | What is the longest duration of a Mp3 file is converted?",
          images: [
            {
              url: "https://getfromyt.com/favicon.png",
              width: 500,
              height: 500,
              alt: "Getfromyt_logo",
            },
          ],
          site_name: "Getfromyt",
        }}
        twitter={{
          handle: "@Getfromyt",
          site: "@Getfromyt",
          cardType: "summary_large_image",
        }}
        facebook={{
          appId: "2646194088934256",
        }}
      />
      <DescriptionSection title={<>FAQ</>} contents={FAQPageData} />
    </>
  );
};

export default FAQPage;
