import React from "react";
import { NextPage } from "next";
import { CutterPage } from "../routes/CutterPage";
import { NextSeo } from "next-seo";
import { DescriptionSection } from "../components/DescriptionSection/DescriptionSection";
import { cutterPageData } from "../static/cutterPageData";

const YoutubeCutterPage: NextPage = () => {
  return (
    <>
      <NextSeo
        title="YouTube Cutter: Cut and Download Video & Mp3 | Getfromyt"
        description="Getfromyt is a Cutter which will crop a part video from YouTube and download to Audio (Mp3) & Video (Mp4). It can be used as a ringtone maker"
        canonical="https://getfromyt.com/youtube-cutter"
        openGraph={{
          type: "website",
          url: "https://getfromyt.com/youtube-cutter",
          title: "YouTube Cutter: Cut and Download Video & Mp3 | Getfromyt",
          description:
            "Getfromyt is a Cutter which will crop a part video from YouTube and download to Audio (Mp3) & Video (Mp4). It can be used as a ringtone maker",
          images: [
            {
              url: "https://getfromyt.com/favicon.png",
              width: 500,
              height: 500,
              alt: "Getfromyt_logo",
            },
          ],
          site_name: "Getfromyt",
        }}
        twitter={{
          handle: "@Getfromyt",
          site: "@Getfromyt",
          cardType: "summary_large_image",
        }}
        facebook={{
          appId: "2646194088934256",
        }}
      />
      <CutterPage />

      <div id="container-6815302cc79b57306fba8748f39fdbc1" />

      <DescriptionSection contents={cutterPageData} />
    </>
  );
};

export default YoutubeCutterPage;
