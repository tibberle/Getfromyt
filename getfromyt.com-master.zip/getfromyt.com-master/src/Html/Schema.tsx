import React from "react";
import Head from "next/head";

export interface SchemaProps {
  name: string;
  url: string;
}

export const Schema: React.FunctionComponent<SchemaProps> = ({ name, url }) => {
  return (
    <Head>
      {/* <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: `{
            "@context": "http://www.schema.org",
            "@type": "WebSite",
            "name": "Getfromyt: Cut, Join, Convert Mp3 From YouTube For Free",
            "alternateName": "${name}",
            "url": "${url}"
            }`,
        }}
      ></script> */}
    </Head>
  );
};
