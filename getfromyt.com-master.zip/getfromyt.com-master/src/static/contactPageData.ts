export const ContactPageData = [
  {
    title: "",
    content: [
      `Do you have any suggestions or questions to discuss with us? Maybe you
      want us to improve the feature for <a href="/" target="_blank">Getfromyt</a>? Feel free to send us a
      message. Please note that we will only answer contact requests written
      in English. Although we do not guaranty an instant response, we will
      try our best to respond as soon as possible, within 24 hours.`,
      `<b>Please note:</b> <br/>Before you report
      an error, please check our
      <a href="/faq" target="_blank">FAQ</a> for the error details.
      Thank you.`,
    ],
  },
];
