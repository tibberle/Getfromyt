export const MaintenanceData = [ 
  `We are currently upgrading our services (even better speed) and
the site will return to normal
<strong>as soon as possible</strong>. Meanwhile you can have a
check in our <a path="/news">News</a> and let see what we are doing. You can also contact us via <a path="/contact">Contact</a> to let us know your issues. Thanks for your patience.`
];
