export const cutterPageData = [
  {
    titleHtmlTag: 'h2',
    title: "How Can I Cut And Download Video Online From YouTube?",
    content: [
      `It is easy right now! With just a few step like: "go to a search engine", type some keywords like: 
      "How to trim a video online from YouTube" or just basically find some of the best tools which will help you to do it! 
      But, do you think it is fast enough to save time and keep your best experiences? The answer is "Maybe" because some of them are quite good about quality. 
      However, they completely fail about speed. And, we can see many and many video cutter like that. They just work well a part and fail another. 
      Or fail both! I used a lot of software like this. And, that's why we are here for you <b>the best Video Cutter</b>. Let's see what we have!!! `,
    ],
  },
  {
    titleHtmlTag: 'h3',
    title: "YouTube To Ringtone???",
    content: [
      `Why it that? At the introduction of a tool: "<a href="/" target="_blank">YouTube Converter</a>" I talked about this function. 
      You can ask google by using the keyword: "youtube to ringtone" or something like that but it is not necessary. 
      You can use our tool as the best Ringtone Maker.`,
    ],
  },  
  {
    titleHtmlTag: 'h3',
    title: "What Do We Have?",
    content: [
      `Firstly, we will serve a tool which will get YouTube videos and after that crop them to create some of best short clips for you only.`,
      `Secondly, it will be a fastest speed you have ever seen. When you click "finish", just 1s and you will able to enjoy with that.`,
      `Finally, the quality of video (Mp4) will be put at 720p and audio (Mp3) will be 128kbps.`,
      `***Note: all of these will not be required for a registration to use.`,
    ],
  },
  {
    titleHtmlTag: 'h3',
    title: "Only YouTube Resource",
    content: [
      `The rule you have to follow is that: "We Only Support For YouTube". 
      It mean you cannot use a source from Facebook or other sources and require us to do it. 
      We will deny :). But don't worry, you can <a href="/contact" target="_blank">contact us</a> to let us know what it is necessary to add to Getfromyt.`,
    ],
  },
  {
    titleHtmlTag: 'h2',
    title: "How To Trim YouTube Videos?",
    content: [
      `Step 1: Go to youtube.com.`,
      `Step 2: Search for a video or a song you want to crop.`,
      `Step 3: Copy the link.`,
      `Step 4: Go to <a href="/youtube-cutter">getfromyt.com/youtube-cutter</a> and paste this link into the search box.`,
      `Step 5: Wait for a few second and now you can set the duration (for the time to start and to end).`,
      `Step 6: It is a step for options. We available have 2 options for you.`,
      `Step 7: When you chose the file type you want to convert, click "crop" button.`,
      `Step 8: Wait 1s for the convert. Click "Download Now" and finish!!!`,
    ],
  },
  {
    titleHtmlTag: 'h2',
    title: "Conclusion",
    content: [
      `And… That it's for Getfromyt. Let's share with your friend if you are interesting!!!`,
    ],
  },
];
