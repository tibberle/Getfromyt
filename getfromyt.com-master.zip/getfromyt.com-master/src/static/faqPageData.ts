export const FAQPageData = [
  {
    titleHtmlTag: 'h2',
    title: "1. Why does the link generate take a long time?",
    content: [
      `
      This is because we try to provide the download link with max speed for
      you so it may take a little bit longer than usual.`,
    ],
  },
  {
    titleHtmlTag: 'h2',
    title: "2. I stuck on converter step, what's wrong?",
    content: [
      `
          Please try to clear the cache on your browser <b>(Ctrl + F5)</b>. Please
          also make sure that you turn off the AdBlock or any similar ad-blocking
          extension. If you still get stuck, please contact us via 
          <a href="/contact" target="_blank">Contact Us</a> with the video
          URL and why you had stuck.`,
    ],
  },
  {
    titleHtmlTag: 'h2',
    title: "3. What is the longest duration of the video that our services support?",
    content: [
      `
          Our service provides <b>any duration</b> video and you may take a long time while converting longer video.`,
    ],
  },
  { 
    titleHtmlTag: 'h2',
    title: "4. How to get files from YouTube Videos?",
    content: [
      `
          After you converted the song, there is a button called "Download Now",
          click on it and the file will automatically be saved into your computer.
          Our service provides for users three tools:
          <a href="/" target="_blank">YouTube Downloader</a>, <a href="/youtube-cutter" target="_blank">YouTube Trimmer</a> and <a href="/youtube-joiner">YouTube Merger</a>.`,
    ],
  },
  {
    titleHtmlTag: 'h2',
    title: "5. Which devices can be used with our services?",
    content: [
      `
          We support almost all devices except the IOS device. We are currently
          working on this issue.`,
    ],
  },
];
