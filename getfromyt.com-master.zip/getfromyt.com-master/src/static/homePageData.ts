export const HomePageData = [
  {
    titleHtmlTag: 'h2',
    title: "How Can I Convert A Video Or A Music From YouTube?",
    content: [
      ` It is also the question I asked for a long time. 
      But, I had no answer for this. Because, the internet in that time is limited. This is one day, 
      I heard a very motivational song. As a result, 
      I wanted to save it to replay many times. 
      And, of course, I stuck!! I searched for a lot keywords on Google such as: 
      "youtube to mp3", "download from youtube" and a list of "how-to" but I found nothing. 
      `,`
      For the next few months, technology updated and became more powerful. At that time, a trend appeared and was very popular in my country. 
      Everyone was trying to have a shortcut of their favourite songs and use them as a ringtone. 
      And, I also want to!! Once again, I researched about this but everything changed and I knew how to do that? 
      And, I was so happy!!`,
      // `***Nowadays, we already served a tool called: "YouTube Cutter". 
      // This software can help you cut a YouTube video and then download them into a video (Mp4) or audio (Mp3) based on your choice.
      // <br/>
      // <a href="/youtube-cutter" target="_blank"> --> Try this YouTube Cutter</a>
      // `
      ,`But, wait! I thought I could <a href="/youtube-cutter" target="_blank">cut and convert a song</a> as the same time. Because that, it would possible to solve just one thing. 
      And, I immediately found the way to do and I discovered a converter which can help me solve the problem. 
      `,`***Thanks for: ClipConverter.cc
      `,
    ]
  },
  {
    titleHtmlTag: 'h2',
    title: "Let's Use Our Service For The Best Trial",
    content: [
      `What do we have? Which features we provide? and How much value you can get from us? There are these answers:`,
    ],
  },
  {
    titleHtmlTag: 'h3',
    title: "What Are We Called?",
    content: [
      `We are "Getfromyt". What does it mean? 
      It is not only extract YouTube videos to Mp3 or Mp4 but also all of these file types you can think of. 
      For example: WAV, WMA, AAC, FLAC, MOV, FLV,... We know some of these are still not available but we will add them in a near future.`,
    ],
  },
  {
    titleHtmlTag: 'h3',
    title: "The Value You Can Get From Us:",
    content: [
      `Firstly, all of type files for audio will be put at 128kbps of quality.`,
      `Secondly, all of type files for video will be put at 720p of quality.`,
      `Finally, you will not waste time to have a registration.`,
      `***Bonus: you can enjoy with the product which you got from us anywhere and anytime.`,
      `***Contact Us: Maybe you want to have an update about quality or something else. Let's feel free to <a href="/contact" target="_blank">contact us</a>. We will do all best to satisfy you!!`,
    ],
  },
  {
    titleHtmlTag: 'h2',
    title: "Only YouTube",
    content: [
      `You reached this point in several ways in this page. I may know them through heading, title but I still want to remind it to you. 
      That is the support for YouTube Only. We will say no with Facebook, Twitter, Soundcloud, ... 
      Once again, contact us if you want to expand some new features.`,
    ],
  },
  {
    titleHtmlTag: 'h2',
    title: "How To Use Our Service?",
    content: [
      `Step 1: Go to <a href="https://www.youtube.com/" rel="nofollow" target="_blank">YouTube</a>.`,
      `Step 2: Search for videos you want to get.`,
      `Step 3: Copy the link.`,
      `Step 4: Go to <a href="/">getfromyt.com</a> and paste this link into the search box.`,
      `Step 5: Choose the type file. It is available for Mp3 and Mp4.`,
      `Step 6: Click "enter" or the "submit" button.`,
      `Step 7: Click "Download Now" and finish!!!`,
    ],
  },
  {
    titleHtmlTag: 'h2',
    title: "Conclusion",
    content: [
      `And… That it's for Getfromyt. 
      That is a tool for you to complete both assignments. 
      We hope you will be interested in our service and recommend them for your friend about this AWESOME feature to get your favourite songs.`,
    ],
  },
];
