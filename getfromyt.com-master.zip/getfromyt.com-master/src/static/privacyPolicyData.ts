export const PrivacyPolicyData = [
  {
    titleHtmlTag: "h2",
    title: "To Begin:",
    content: [
      `When you access Getfromyt, accessible from
      <a href="/" target="_blank">https://getfromyt.com</a>. This Privacy
      Policy document show to you these types of information that is collected and
      recorded by us.`,
      `But, we will not know exactly how you are?.`,
      `If you have any question. Please <a href="/contact" target="_blank">contact us</a>.`,
    ],
  },
  {
    titleHtmlTag: "h3",
    title: "Agreement",
    content: [
      `By using our website, you need to agree with all of our <a href="/terms-of-service" target="_blank">Terms Of Service</a> and Privacy
      Policy.`,
    ],
  },
  {
    titleHtmlTag: "h2",
    title: "Information we collected",
    content: [`We dont collect any of your personal information`],
  },
  {
    titleHtmlTag: "h2",
    title: "Cookies",
    content: [
      `You will not have to accept any cookie when you visit our site. 
      This mean the information of videos youtube which you converted by our tool will not be recorded.`,
    ],
  },
];
