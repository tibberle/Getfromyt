export const joinerPageData = [
  {
    titleHtmlTag: "h2",
    title: "How Can I Put Two Video Clips or Two Songs Together?",
    content: [ 
      `I think you have ever stuck to find the answer for this one. As you already knew, the <a href="https://mashable.com/2017/07/23/youtube-kills-video-editor-tool/" rel="nofollow" target="_blank">Video Editor Online was canceled by YouTube on September 2017</a>. 
      At that time, you would not see too many video editors could fill this place. If you could find, it was just a replace. 
      I didn't say these tools are not good but they are not necessary because you just need a feature to merge videos or audios online on YouTube but you have to purchase to be unlimited your experiences. 
      `,
      `That's not necessary! If you don't purchase and use for free, you will be received a "Watermark" and a lot of things will make you unhappy. 
      That's why we make this feature which is called: "<strong>YouTube Merger</strong>" to serve for you. Let's what we already have!!!`,
    ],
  },
  {
    titleHtmlTag: "h3",
    title: "Which Things Our Video Combiner can serve for you?",
    content: [
      `Firstly, you will able to merge videos and songs from YouTube 100% for free and you also don't waste time to register for an account. You also don't need to download a tool into your device because it is "Online".`,
      `Secondly, it will help you to export files with the quality of videos at 720p and audios at 128kbps.`,
      `Thirdly, you can merge up to <b>3 Videos (or 5 Audios)</b> and download them into one file at the same time.`,
      `Finally, type files will be Mp3 for Audio and Mp4 for Video. We don't have other options at the moment but if you need. Please <a href="/contact" target="_blank">contact us</a>, we will add into other type files to serve for you.`,
      `***Bonus: the combining will be fast (just 1s) and don't waste your time.`,
      `***The duration of songs or videos which you get from <a href="https://www.youtube.com/" rel="nofollow" target="_blank">YouTube</a> have to under 30 minutes.`,
    ],
  },
  {
    titleHtmlTag: "h3",
    title: "Get From YouTube And Serve For YouTube",
    content: [
      `Our service is a media editor for YouTube only, you can use them to save musics or videos from YouTube and then publish them back to YouTube for fun or earning money if you want. 
      But, please notice that you cannot upload videos or audios from your computer or import other sources. 
      Just YouTube and YouTube only. It is not only this feature but also other features from our service. 
      <a href="/youtube-cutter" target="_blank">Video Cutter</a> or <a href="/" target="_blank">Video Converter</a> are still like that!!! `,
    ],
  },
  {
    titleHtmlTag: "h2",
    title: "How To Combine Videos (Songs) On YouTube?",
    content: [
      `Let's follow this guide to try the first time for an easy and fast way:`,
      `Step 1: Go to YouTube (by this URL: https://www.youtube.com/).`,
      `Step 2: Search for videos or songs you want to merge. ( We only support FREE videos )`,
      `Step 3: Copy their links (one link per time).`,
      `Step 4: Go to <a href="/youtube-joiner">getfromyt.com/youtube-joiner</a> and paste these links (one link per time) into the search box.`,
      `Step 5: Now, you can drag and drop to arrange them.`,
      `Step 6: Select the type file to merge and download. It is available for audio (Mp3) and video (Mp4).`,
      `Step 7: Click "Enter" or the "Merge" button.`,
      `Step 8: Click "Download Now" and enjoy!!!`,
    ],
  },
  {
    titleHtmlTag: "h2",
    title: "Conclusion",
    content: [
      `And… That it's for Getfromyt. That is a merger will allow you to combine videos or songs Online from YouTube and download them into video files (or audio files). 
      Your favourite playlist will be created in here. So, if you love this feature, let's share it!!!`,
    ],
  },
  {
    titleHtmlTag: "h3",
    title: "It will available soon!!! - But if:",
    content: [ 
      `Because of some problems, we cannot make it available now! - <strong>Let's show us your wanting by typing: "Joiner"</strong> at the contact page and send it to us. 
      We will consider and serve to you as soon as we can!!! 
      `,
    ],
  },
];
