export const AboutPageData = [
  {
    titleHtmlTag: "h2",
    title: "Introduction",
    content: [
      `Getfromyt is an online service that help you download free Youtube Video ( We only support publicly free videos from youtube ) with lightening speed because of our CDN. 
      We also use various open-source tools for cutting videos or extracting audio from the video. Easy to use, the fastest free <a href="/" target="_blank">youtube downloader</a> service you can find on the internet.`
    ],
  },
];
