export const TOSPageData = [
  { title: "", content: ["Last updated: 19 December, 2020"] },
  {
    title: "",
    content: [
      `Please read these Terms and Conditions carefully before using Our Service.`,
      `<strong> ** If you do not agree with any of those, you have no right to use this website.</strong>`,
      ,
    ],
  },
  {
    titleHtmlTag: "h2",
    title: "Dont try to download paid videos.",
    content: [`We dont support downloading paid youtube videos in any way.`],
  },
  {
    titleHtmlTag: "h2",
    title: "Dont try to download videos that are blocked in your contries",
    content: [
      `If you cannot watch any videos because it is banned in your country. This means that these videos cannot be downloaded by our website. We don't help you to bypass youtube region restriction rule in any way.`,
    ],
  },
  {
    titleHtmlTag: "h2",
    title: "Dont use our service if you're under 13 years old.",
    content: [
      `We, getfromyt.com: <a href="/" target="_blank">YouTube Converter</a>, strictly adhere to youtube restriction ( including age, region,.. ) policy, so if you are under 13 years old, DO NOT use our service by any means.`,
    ],
  },
];
