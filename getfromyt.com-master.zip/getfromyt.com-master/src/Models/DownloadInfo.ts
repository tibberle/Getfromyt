export interface DownloadInfoModel {
  downloadLink: string;
  title: string;
}
