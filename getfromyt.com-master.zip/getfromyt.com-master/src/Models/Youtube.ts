export interface Youtube {
  downloadLink: string;
  duration: number;
  id: string;
  title: string;
}

export enum YoutubeType {
  Video = "Video",
  Audio = "Audio",
}
