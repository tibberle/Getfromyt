export interface CuttingModel {
    id: string,
    startInMilliSeconds: number,
    endInMilliSeconds: number
}