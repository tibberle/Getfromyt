/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import React from "react";
import { InfoCard } from "../components/InfoCard/InfoCard";
import { InternalRedirect } from "../components/InternalRedirect/InternalRedirect";
import { Paper } from "../components/Paper/Paper";
import { Typography } from "../components/Typography/Typography";
import { EXTRA_LARGE_SPACING_REM } from "../styles/globalStyleConstants";

const InfoCardWrapper = styled.div`
  width: 70%;
`;

export interface NewsRouteProps {}

export const NewsRoute: React.FunctionComponent<NewsRouteProps> = () => {
  return (
    <Paper
      center
      css={css`
        padding: ${EXTRA_LARGE_SPACING_REM}rem 0;
      `}
    >
      <Typography
        tag="h1"
        variant="h1"
        css={css`
          padding-bottom: ${EXTRA_LARGE_SPACING_REM}rem;
        `}
      >
        News
      </Typography>
      <InfoCardWrapper>
        <InfoCard
          title="What's next?"
          subTitle="06 December, 2020"
          descriptions={[
            <>
              We are planning to make a comprehensive online{" "}
              <a href="/youtube-cutter" target="_blank">
                video/audio editor
              </a>{" "}
              that allow you edit video/audio without any limit. We are working
              in this project and we love to hear more about your idea on this
              project. Of course, we will give you some nice rewards for your
              contribution. Please suggest us via{" "}
              <a href="/contact" target="_blank">
                contact us
              </a>
            </>,
          ]}
        />
        <InfoCard
          title="Released Getfromyt 3.0"
          subTitle="06 December, 2020"
          descriptions={[
            <>
              We removed our{" "}
              <a href="/youtube-joiner" target="_blank">
                joiner
              </a>{" "}
              services due to performance and we are happy to introduce new
              video downloader and video cutter to our website. Also, we updated
              cutter service interface for the ease of use. We also renovated
              our website interface with a better and modern look. If you have
              suggestion, please contact us via{" "}
              <a href="/contact" target="_blank">
                contact us
              </a>
            </>,
          ]}
        />
        <InfoCard
          title="Update Audio Cutter 2.1"
          subTitle="3 November, 2020"
          descriptions={[
            <>
              We just finished our converter today. If it is not working for
              you, please delete your browser by using{" "}
              <strong>"Ctrl + F5"</strong> and try again. If it doesn't work,
              please contact us via{" "}
              <a href="/contact" target="_blank">
                contact us
              </a>
            </>,
          ]}
        />
        <InfoCard
          title="Update Audio Cutter 2.0"
          subTitle="26 july, 2020"
          descriptions={[
            <>
              We just updated our new Audio Cutter 2.0. You can experiment it in
              here{" "}
              <a href="/youtube-cutter" target="_blank">
                YouTube Mp3 Cutter
              </a>
              . If it is not working for you, please delete your browser cache
              by using <strong>"Ctrl + F5"</strong> and try again. If it doesn't
              work, please contact us via{" "}
              <a href="/contact" target="_blank">
                contact us
              </a>
            </>,
          ]}
        />
        <InfoCard
          title="Update Audio Cutter"
          subTitle="19 july, 2020"
          descriptions={[
            <>
              We just finished our new Audio Cutter today. You can try it in
              here{" "}
              <a href="/youtube-cutter" target="_blank">
                YouTube Mp3 Cutter
              </a>
              . If it is not working for you, please delete your browser cache
              by using <strong>"Ctrl + F5"</strong> and try again. If it doesn't
              work, please contact us via{" "}
              <a href="/contact" target="_blank">
                contact us
              </a>
            </>,
          ]}
        />
        <InfoCard
          title="Major update on Converter"
          subTitle="12 july, 2020"
          descriptions={[
            <>
              We just finished our converter today. If it is not working for
              you, please delete your browser by using{" "}
              <strong>"Ctrl + F5"</strong> and try again. If it doesn't work,
              please contact us via{" "}
              <a href="/contact" target="_blank">
                contact us
              </a>
            </>,
          ]}
        />
      </InfoCardWrapper>
    </Paper>
  );
};
