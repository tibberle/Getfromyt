/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import React from "react";
import { DescriptionSection } from "../components/DescriptionSection/DescriptionSection";
import { DownloadBar } from "../components/DownloadBar/DownloadBar";
import { DownloadInfo } from "../components/DownloadInfo/DownloadInfo";
import { DownloadSection } from "../components/DownloadSection/DownloadSection";
import { Typography } from "../components/Typography/Typography";
import { HomePageData } from "../static/homePageData";
import {
  EXTRA_LARGE_SPACING_REM,
  SMALL_SPACING_REM,
} from "../styles/globalStyleConstants";

export const HomePage: React.FunctionComponent = () => {
  return (
    <>
      <DownloadSection
        note={
          <>
            <Typography
              variant="helper"
              tag="p"
              css={css`
                margin: 0 ${EXTRA_LARGE_SPACING_REM}rem;
              `}
            >
              <strong>Note:</strong> Insert <strong>"gf"</strong> like the image
              to convert YouTube to Mp3 (Mp4) and then download them in a fast
              way.
            </Typography>
            <img
              src="/tip.png"
              alt="youtubegf tip"
              css={css`
                margin-top: ${SMALL_SPACING_REM}rem;
                @media (max-width: 470px) {
                  width: 90%;
                }
              `}
            />
          </>
        }
        title={"YouTube Converter"}
        description={"Download Mp3 & Mp4 Online - High Quality"}
        downloadBar={<DownloadBar />}
        downloadInfo={<DownloadInfo />}
      />

      <DescriptionSection contents={HomePageData as any} />
    </>
  );
};
