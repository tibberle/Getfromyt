/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import { Suspense } from "react";
import { Cutter } from "../components/Cutter/Cutter";
import { DownloadBar } from "../components/DownloadBar/DownloadBar";
import { DownloadInfoForCutter } from "../components/DownloadInfo/DownloadInfoForCutter";
import { DownloadSection } from "../components/DownloadSection/DownloadSection";

export interface CutterPageProps {}

export const CutterPage: React.FunctionComponent<CutterPageProps> = () => {
  return (
    <DownloadSection
      title={"YouTube Cutter"}
      description={"Download A part of Video To Mp3 & Mp4"}
      downloadBar={<DownloadBar />}
      cutter={
        <Suspense fallback={null}>
          <Cutter />
        </Suspense>
      }
      downloadInfo={<DownloadInfoForCutter />}
    />
  );
};
