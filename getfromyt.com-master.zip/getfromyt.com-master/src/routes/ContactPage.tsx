/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import React from "react";
import { toast } from "react-toastify";
import { Button } from "../components/Button/Button";
import { DescriptionSection } from "../components/DescriptionSection/DescriptionSection";
import { Paper } from "../components/Paper/Paper";
import { TextField } from "../components/TextField/TextField";
import { Typography } from "../components/Typography/Typography";
import { EmailService } from "../services/EmailService";
import { ContactPageData } from "../static/contactPageData";
import {
  DEFAULT_SPACING_REM,
  EXTRA_LARGE_SPACING_REM,
  LARGE_SPACING_REM,
} from "../styles/globalStyleConstants";

export const StyledTextFieldWrapper = styled.div<{ fullWidth?: boolean }>`
  margin-bottom: ${LARGE_SPACING_REM}rem;
  display: flex;
  width: ${(props) => (props.fullWidth ? "100%" : "70%")};
  @media (max-width: 570px) {
    width: 90%;
  }
`;

function validateEmail(email: string) {
  return email.match(
    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
  );
}

export interface ContactRouteProps {}

export const ContactRoute: React.FunctionComponent<ContactRouteProps> = () => {
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [message, setMessage] = React.useState("");

  const sendMail = async () => {
    try {
      await EmailService.send({ name, email, message });
      toast.success("We will be in touch :) :) ");
    } catch (error) {
      toast.error("Please try again");
    }
  };

  return (
    <>
      <DescriptionSection
        title={<>Contact Us</>}
        contents={ContactPageData as any}
      />
      <Paper
        css={css`
          margin-top: ${DEFAULT_SPACING_REM}rem;
          padding: ${EXTRA_LARGE_SPACING_REM}rem;
        `}
        center
      >
        <Typography
          variant="h2"
          tag="h2"
          css={css`
            margin-left: auto;
            margin-right: auto;
            margin-bottom: ${EXTRA_LARGE_SPACING_REM}rem;
          `}
        >
          Contact Form
        </Typography>
        <StyledTextFieldWrapper>
          <TextField
            onChange={setName}
            label="Name"
            placeholder="John Doe"
            required
          />
        </StyledTextFieldWrapper>
        <StyledTextFieldWrapper>
          <TextField
            onChange={setEmail}
            label="email"
            placeholder="admin@getfromyt.com"
            required
          />
        </StyledTextFieldWrapper>
        <StyledTextFieldWrapper>
          <TextField
            label="Message"
            placeholder="What do you need us for?"
            textarea
            required
            onChange={setMessage}
          />
        </StyledTextFieldWrapper>
        <Button
          disabled={!name || !message || !validateEmail(email)}
          onClick={sendMail}
        >
          Submit
        </Button>
      </Paper>
    </>
  );
};
