import React from "react";
import { Custom404 } from "../components/Custom404/Custom404";

export interface Custom404RouteProps {}

export const Custom404Route: React.FunctionComponent<Custom404RouteProps> = () => {
  return <Custom404 />;
};
