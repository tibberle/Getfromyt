import React from "react";
import { DownloadBar } from "../components/DownloadBar/DownloadBar";
import { DownloadInfo } from "../components/DownloadInfo/DownloadInfo";
import { DownloadSection } from "../components/DownloadSection/DownloadSection";

export interface JoinerRouteProps {}

export const JoinerRoute: React.FunctionComponent<JoinerRouteProps> = () => {
  return (
    <>
      <DownloadSection
        title={"YouTube Merger"}
        description={"Merge And Download Videos & Audios Online"}
        downloadBar={<DownloadBar />}
        downloadInfo={<DownloadInfo />}
        maintenance={true}
      />
    </>
  );
};
