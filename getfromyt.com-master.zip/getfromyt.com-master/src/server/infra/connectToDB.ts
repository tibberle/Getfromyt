// @ts-nocheck
import { Db, MongoClient } from "mongodb";

globalThis.mongo = globalThis.mongo || {};

export const connectToDB = async () => {
  if (!globalThis.mongo.client) {
    globalThis.mongo.client = new MongoClient(process.env.SURVEY_DATABASE_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      bufferMaxEntries: 0,
      connectTimeoutMS: 10000,
    });

    console.log("connecting to DB");
    await globalThis.mongo.client.connect();
    console.log("connected to DB");
  }
  console.log("connected to DB using existing connection");

  const db: Db = globalThis.mongo.client.db("");

  return { db, dbClient: globalThis.mongo.client };
};
